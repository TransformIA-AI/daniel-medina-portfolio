
  # Tier-S

  This is a code bundle for Tier-S. The original project is available at https://www.figma.com/design/HC6gl8JCEg0TmFfSAIoP1f/Tier-S.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  
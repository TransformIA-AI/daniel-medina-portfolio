import { createBrowserRouter } from "react-router";
import { Root } from "./components/Root";
import { HomePage } from "./components/HomePage";
import { CaseStudyPage } from "./components/CaseStudyPage";
import { LinkedInAssetsPage } from "./components/LinkedInAssetsPage";
import { DesignSystemPage } from "./components/DesignSystemPage";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: HomePage },
      { path: "case/:slug", Component: CaseStudyPage },
      { path: "assets", Component: LinkedInAssetsPage },
      { path: "design-system", Component: DesignSystemPage },
    ],
  },
]);

import { useParams, Link } from "react-router";
import {
  ArrowLeft,
  Building2,
  Calendar,
  Users,
  Target,
  Lightbulb,
  Wrench,
  TrendingUp,
  BookOpen,
  Shield,
  ChevronRight,
  CheckCircle2,
  ExternalLink,
  Brain,
} from "lucide-react";

const NAVY = "#0B1D3A";
const TEAL = "#1A7A6E";
const TEAL_LIGHT = "#E8F5F2";
const CARBON = "#1C1C1E";
const SECONDARY = "#5A5A5A";
const BORDER = "#E4E4DF";
const CARD_BG = "#FFFFFF";
const PAGE_BG = "#FAFAF8";

type CaseStudy = {
  slug: string;
  org: string;
  role: string;
  period: string;
  location: string;
  headline: string;
  accentColor: string;
  tags: string[];
  context: string;
  challenge: string;
  approach: string[];
  hitl: string;
  tools: string[];
  impact: string[];
  lessons: string[];
  disclaimer: string;
  nextSlug?: string;
  nextLabel?: string;
};

const CASES: Record<string, CaseStudy> = {
  ayesa: {
    slug: "ayesa",
    org: "Ayesa",
    role: "AI Strategy & Digital Workplace Architect | Project Manager",
    period: "Aug 2025 – Dec 2025",
    location: "Madrid, Spain",
    headline: "Digital Workplace & Public Sector Transformation",
    accentColor: NAVY,
    tags: ["Digital Workplace", "ITSM", "Public Sector", "Project Management", "Atlassian JSM", "Applied AI"],
    context:
      "Ayesa is a leading Spanish technology and engineering company. The engagement involved digital transformation consulting for public sector and large organizations — Modern Workplace adoption, user experience redesign, ITSM implementation and applied AI documentation. Projects spanned Madrid Digital, Ministerio de Justicia, UOC and ICEX.",
    challenge:
      "Public sector organizations face structural complexity: multi-stakeholder governance, legacy processes, regulatory constraints and low digital literacy. The challenge was to drive Modern Workplace adoption while ensuring operational continuity, executive documentation quality and measurable service improvements.",
    approach: [
      "Led ICEX project as Project Manager: coordination of all deliverables, tracking against milestones, validation gates and final client delivery.",
      "Functional analysis and executive documentation across multiple public sector clients (Madrid Digital, Justice, UOC, ICEX).",
      "Atlassian Jira Service Management (JSM) implementation: service workflow design, ticketing architecture, documentation and operational adoption.",
      "Stakeholder management across public sector executives, technical teams and end users.",
      "Applied AI documentation layer: executive summaries, process maps and governance artifacts using AI-assisted drafting with human review.",
    ],
    hitl:
      "All executive documentation went through a structured human review loop before client delivery. AI-assisted drafting was used to increase speed and consistency, but every deliverable was validated, edited and signed off by the responsible consultant. No automated output was delivered directly to clients without human review.",
    tools: ["Atlassian Jira Service Management", "Microsoft 365 / SharePoint", "Confluence", "Figma", "Codex", "n8n (documentation automation)", "Excel / PowerPoint"],
    impact: [
      "Successful delivery of ICEX project with full client validation",
      "Atlassian JSM implementation covering service workflows, ticketing and operational adoption",
      "Executive documentation standards established for public sector delivery",
      "Applied AI processes integrated into documentation workflow with HITL oversight",
    ],
    lessons: [
      "Public sector delivery requires patience with governance cycles — milestones must be scoped against institutional constraints.",
      "ITSM adoption succeeds when users are trained alongside the technical implementation, not after.",
      "AI-assisted documentation multiplies output quality when paired with strong editorial review.",
    ],
    disclaimer:
      "This case study contains only public-safe information. No client data, internal systems or confidential deliverables are exposed. All project references are limited to publicly known engagements.",
    nextSlug: "konecta",
    nextLabel: "Konecta: Operations Transformation at Scale",
  },
  konecta: {
    slug: "konecta",
    org: "Konecta",
    role: "Business Manager · General Service Lead",
    period: "Apr 2023 – Aug 2025",
    location: "Spain · Portugal · Colombia",
    headline: "Operations Transformation at Scale",
    accentColor: "#1E3A5F",
    tags: ["Operations Leadership", "P&L Management", "CX", "Insurance", "Contact Center", "Multi-Country"],
    context:
      "Konecta is a global BPO leader. The engagement was as General Service Lead for Liberty Seguros across multi-service, multi-country, high-volume operations. Scope included inbound and outbound sales, post-sales, retention, collections, partners, mediators, claims, cross-sell, upsell and commercial campaigns.",
    challenge:
      "Managing 560+ people across three countries with €12M+ P&L while maintaining SLA compliance, productivity, quality and client relationship. The complexity was compounded by multi-service scope, geographic spread and constant commercial pressure from the insurance client.",
    approach: [
      "Directed operations, middle management, quality, planning and reporting across Spain, Portugal and Colombia — up to 560 people.",
      "Full P&L responsibility: billing, collections, client interlocution, SLA tracking, productivity and efficiency management.",
      "Weekly executive presentations to Liberty Seguros: performance dashboards, SLA/KPI analysis, action plans and commercial projections.",
      "Functional definition of operational and commercial scripting for the auto-dialer system with technical teams.",
      "Continuous improvement cycles: process redesign, workforce optimization and quality framework governance.",
    ],
    hitl:
      "Large-scale operations always require human decision loops for edge cases, escalations and P&L-impacting decisions. In this role, all material operational decisions — workforce reductions, SLA breaches, client escalations, commercial strategy shifts — were escalated through a governance chain with defined approval owners. No automated action replaced human judgment for consequential decisions.",
    tools: ["Salesforce CRM", "WFM (Workforce Management)", "Power BI", "Excel / Advanced Analytics", "Avaya (contact center)", "Auto-dialer platforms", "Internal QA frameworks"],
    impact: [
      "Led 560+ people across 3 countries maintaining SLA compliance",
      "P&L management above €12M with billing, collections and efficiency governance",
      "Multi-service delivery: sales, post-sales, retention, collections, claims and cross-sell",
      "Weekly executive reporting to Liberty Seguros with measurable performance outcomes",
      "Commercial scripting optimization contributing to conversion and retention metrics",
    ],
    lessons: [
      "At scale, governance systems are more important than individual brilliance — documented processes, clear accountability and escalation paths are the real infrastructure.",
      "Remote multi-country operations require more deliberate communication rhythms: weekly syncs, clear KPI dashboards and rapid escalation channels.",
      "Client-facing P&L management builds credibility fastest when you show up with data, own the problems and propose solutions rather than explanations.",
    ],
    disclaimer:
      "This case study contains only public-safe information. Financial figures are general in nature and reflect publicly known scope. No confidential client data, internal systems or SLA-specific metrics are exposed.",
    nextSlug: "transformia",
    nextLabel: "TransformIA AI Lab: Human-in-the-Loop Workflows",
  },
  transformia: {
    slug: "transformia",
    org: "TransformIA AI Lab",
    role: "Founder · HITL Operator · AI Workflow Architect",
    period: "2024 – Ongoing",
    location: "Madrid, Spain (Remote)",
    headline: "Human-in-the-Loop AI Workflows",
    accentColor: TEAL,
    tags: ["Human-in-the-Loop", "AI Workflows", "Governance", "n8n", "Python", "Codex", "Public-Safe Architecture"],
    context:
      "TransformIA AI Lab is a personal professional lab designed to demonstrate practical enterprise AI — without exposing private code or real client data. It covers workflow automation, Human-in-the-Loop architecture, eWorkers, Digital Workplace tooling, intelligent documentation and operational governance.",
    challenge:
      "The challenge is dual: demonstrating genuine technical competence in applied AI while maintaining a strict public-safe boundary — no private code, no real client data, no unproven ROI claims. The portfolio must be honest proof of work, not a polished fiction.",
    approach: [
      "Designed HITL (Human-in-the-Loop) workflow architecture: every consequential AI action requires explicit human approval before execution.",
      "Built public-safe automation demos using n8n, Python and Codex — demonstrating real orchestration patterns without exposing private implementations.",
      "Developed the Recruiter Concierge as a live demo: deterministic AI assistant that responds to recruiter questions using public portfolio data only.",
      "Documented AI workflow patterns: business intent → AI draft → HITL gate → human-reviewed output → evidence delivery.",
      "Built governance frameworks for AI output quality, traceability and responsible deployment.",
    ],
    hitl:
      "Human-in-the-Loop is the central design principle of this lab — not a safety addendum. Every workflow has a defined gate where a human must review, approve, edit or reject the AI output before it moves forward. This is demonstrated directly in the Recruiter Concierge: no calendar event, no contact action, no recommendation is executed without explicit approval.",
    tools: ["n8n (workflow orchestration)", "Python", "OpenAI / Claude API", "Codex", "GitHub", "Figma", "Markdown / MDX", "RAG patterns", "Git"],
    impact: [
      "Live Recruiter Concierge demonstrating HITL architecture in production",
      "Public-safe workflow documentation covering HITL patterns, governance and automation",
      "Proof-of-work portfolio demonstrating business-AI translation without private code",
      "Technical foundation applied to real professional problems (CV processing, documentation, workflow automation)",
    ],
    lessons: [
      "The hardest part of AI integration in enterprise is not the technology — it's the governance design: defining which actions require human approval and making that non-negotiable.",
      "Public-safe architecture is a discipline, not a limitation. Constrained demos force clarity about what the actual value proposition is.",
      "Human-in-the-Loop is not about distrust of AI — it's about appropriate accountability for consequential actions.",
    ],
    disclaimer:
      "TransformIA AI Lab is a personal professional portfolio. No private client code, data or implementations are exposed. Demos use public data sources and deterministic patterns only. No complete CS50 solutions are published.",
    nextSlug: "harvardx",
    nextLabel: "HarvardX CS50: Technical Foundation for AI",
  },
  harvardx: {
    slug: "harvardx",
    org: "HarvardX · CS50",
    role: "Applied Learner · Technical AI Foundation",
    period: "2024 – 2025",
    location: "Online (HarvardX / edX)",
    headline: "Technical Foundation for AI Transformation",
    accentColor: "#7A5C00",
    tags: ["CS50x", "CS50AI", "Python", "C", "SQL", "Machine Learning", "NLP", "Neural Networks", "HarvardX"],
    context:
      "HarvardX CS50x (Introduction to Computer Science) and CS50AI (Introduction to AI with Python) taken as a deliberate investment to build technical depth as a business executive. Goal: understand enough CS and AI to work credibly alongside engineers, design better systems and identify realistic AI opportunities in operations.",
    challenge:
      "Completing two rigorous Harvard courses while maintaining professional work — bridging the gap between business executive background and technical AI literacy. The challenge was not just completing the courses but translating the learning into applicable frameworks for enterprise AI transformation work.",
    approach: [
      "CS50x: Complete C and Python track, 10 problem sets covering algorithms, data structures, memory, networks, SQL, web programming.",
      "CS50AI: 12 Python AI projects covering search algorithms, knowledge representation, inference, optimization, machine learning, neural networks and NLP.",
      "Applied learning: linked every technical concept to real enterprise use cases — forecasting, document processing, service optimization, AI governance.",
      "Final project: Applied AI demonstration relevant to Digital Workplace and operations contexts.",
      "Continuous translation: built a personal glossary linking CS fundamentals to business outcomes for AI Transformation work.",
    ],
    hitl:
      "In CS50AI, several projects involved systems that make consequential decisions (medical diagnosis simulations, recommendation systems). The learning reinforced that responsible AI deployment requires understanding the failure modes of models — not just accuracy, but what happens when they're wrong and who bears the consequence.",
    tools: ["C", "Python", "SQL", "JavaScript (basics)", "Flask", "TensorFlow / Keras (concepts)", "NLTK", "scikit-learn", "Git / GitHub", "VS Code"],
    impact: [
      "CS50x completed: C, Python, SQL, algorithms, data structures, web basics",
      "CS50AI completed: 12 Python AI projects covering ML, NLP, neural networks, search",
      "Technical vocabulary for credible AI transformation conversations with engineering teams",
      "Direct application to TransformIA AI Lab: Python automation, workflow scripting, RAG patterns",
    ],
    lessons: [
      "The most valuable outcome of CS50 was not the code — it was building intuition for computational thinking and understanding what AI systems can and cannot do.",
      "Business executives don't need to be senior engineers to drive AI transformation. They need enough depth to ask the right questions, scope realistic work and govern output responsibly.",
      "Constraint forces creativity. Working in C before Python is a master class in understanding what abstractions actually cost.",
    ],
    disclaimer:
      "No complete CS50 problem set solutions are published. This case study describes the learning experience and applied outcomes only. HarvardX and CS50 are trademarks of Harvard University.",
    nextSlug: "ayesa",
    nextLabel: "Ayesa: Digital Workplace & Public Sector",
  },
};

function Section({
  icon: Icon,
  title,
  children,
  accentColor,
}: {
  icon: React.ElementType;
  title: string;
  children: React.ReactNode;
  accentColor: string;
}) {
  return (
    <div
      style={{
        backgroundColor: CARD_BG,
        border: `1px solid ${BORDER}`,
        borderRadius: 12,
        padding: "28px 28px",
        marginBottom: 16,
      }}
    >
      <div className="flex items-center gap-3 mb-5">
        <div
          style={{
            width: 36,
            height: 36,
            borderRadius: 8,
            backgroundColor: accentColor + "15",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Icon size={18} color={accentColor} />
        </div>
        <h2 style={{ fontSize: 16, fontWeight: 700, color: CARBON, letterSpacing: "-0.01em" }}>{title}</h2>
      </div>
      {children}
    </div>
  );
}

export function CaseStudyPage() {
  const { slug } = useParams<{ slug: string }>();
  const cs = slug ? CASES[slug] : null;

  if (!cs) {
    return (
      <div style={{ backgroundColor: PAGE_BG, minHeight: "60vh", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ textAlign: "center" }}>
          <div style={{ fontSize: 18, fontWeight: 600, color: NAVY, marginBottom: 8 }}>Case study not found</div>
          <Link to="/" style={{ color: TEAL, fontSize: 14 }}>← Back to portfolio</Link>
        </div>
      </div>
    );
  }

  return (
    <div style={{ backgroundColor: PAGE_BG, minHeight: "100vh" }}>
      {/* Hero */}
      <div
        style={{
          backgroundColor: cs.accentColor,
          padding: "48px 0 40px",
          position: "relative",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            position: "absolute",
            inset: 0,
            backgroundImage: `radial-gradient(circle at 90% 50%, rgba(255,255,255,0.06) 0%, transparent 60%)`,
          }}
        />
        <div className="max-w-4xl mx-auto px-6 relative">
          <Link
            to="/#work"
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: 6,
              color: "rgba(255,255,255,0.6)",
              textDecoration: "none",
              fontSize: 13,
              marginBottom: 24,
            }}
          >
            <ArrowLeft size={14} />
            Back to Case Studies
          </Link>

          <div
            style={{
              display: "inline-block",
              backgroundColor: "rgba(255,255,255,0.15)",
              borderRadius: 4,
              padding: "3px 12px",
              fontSize: 11,
              color: "rgba(255,255,255,0.8)",
              marginBottom: 14,
              fontWeight: 500,
              letterSpacing: "0.06em",
              textTransform: "uppercase",
            }}
          >
            Case Study
          </div>

          <h1
            style={{
              fontSize: "clamp(28px, 4vw, 44px)",
              fontWeight: 800,
              color: "white",
              letterSpacing: "-0.025em",
              lineHeight: 1.15,
              marginBottom: 8,
            }}
          >
            {cs.org}
          </h1>
          <div style={{ fontSize: 18, fontWeight: 500, color: "rgba(255,255,255,0.75)", marginBottom: 20 }}>
            {cs.headline}
          </div>

          <div className="flex flex-wrap gap-3 mb-8">
            {[
              { icon: Building2, text: cs.role },
              { icon: Calendar, text: cs.period },
              { icon: Users, text: cs.location },
            ].map(({ icon: Icon, text }) => (
              <div key={text} className="flex items-center gap-2">
                <Icon size={13} color="rgba(255,255,255,0.5)" />
                <span style={{ fontSize: 13, color: "rgba(255,255,255,0.7)" }}>{text}</span>
              </div>
            ))}
          </div>

          <div className="flex flex-wrap gap-2">
            {cs.tags.map((tag) => (
              <span
                key={tag}
                style={{
                  backgroundColor: "rgba(255,255,255,0.12)",
                  border: "1px solid rgba(255,255,255,0.15)",
                  borderRadius: 4,
                  padding: "4px 10px",
                  fontSize: 11,
                  color: "rgba(255,255,255,0.8)",
                  fontWeight: 500,
                }}
              >
                {tag}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-6 py-12">
        <Section icon={BookOpen} title="Context" accentColor={cs.accentColor}>
          <p style={{ fontSize: 15, color: SECONDARY, lineHeight: 1.75 }}>{cs.context}</p>
        </Section>

        <Section icon={Target} title="Challenge" accentColor={cs.accentColor}>
          <p style={{ fontSize: 15, color: SECONDARY, lineHeight: 1.75 }}>{cs.challenge}</p>
        </Section>

        <Section icon={Lightbulb} title="Approach" accentColor={cs.accentColor}>
          <div className="flex flex-col gap-4">
            {cs.approach.map((step, i) => (
              <div key={i} className="flex gap-4">
                <div
                  style={{
                    width: 28,
                    height: 28,
                    borderRadius: 6,
                    backgroundColor: cs.accentColor,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: 11,
                    fontWeight: 700,
                    color: "white",
                    flexShrink: 0,
                    marginTop: 2,
                  }}
                >
                  {String(i + 1).padStart(2, "0")}
                </div>
                <p style={{ fontSize: 14, color: SECONDARY, lineHeight: 1.7, flex: 1 }}>{step}</p>
              </div>
            ))}
          </div>
        </Section>

        <Section icon={Brain} title="Human-in-the-Loop / Governance" accentColor={TEAL}>
          <div
            style={{
              backgroundColor: TEAL_LIGHT,
              border: `1px solid ${TEAL}33`,
              borderRadius: 8,
              padding: "16px 18px",
            }}
          >
            <p style={{ fontSize: 14, color: "#0D5A50", lineHeight: 1.75 }}>{cs.hitl}</p>
          </div>
        </Section>

        <Section icon={Wrench} title="Tools / Stack" accentColor={cs.accentColor}>
          <div className="flex flex-wrap gap-2">
            {cs.tools.map((tool) => (
              <span
                key={tool}
                style={{
                  backgroundColor: "#F0F0ED",
                  border: `1px solid ${BORDER}`,
                  borderRadius: 5,
                  padding: "5px 12px",
                  fontSize: 13,
                  color: CARBON,
                  fontWeight: 400,
                }}
              >
                {tool}
              </span>
            ))}
          </div>
        </Section>

        <Section icon={TrendingUp} title="Impact" accentColor={cs.accentColor}>
          <div className="flex flex-col gap-3">
            {cs.impact.map((item) => (
              <div key={item} className="flex items-start gap-3">
                <CheckCircle2 size={16} color={cs.accentColor} style={{ flexShrink: 0, marginTop: 2 }} />
                <p style={{ fontSize: 14, color: SECONDARY, lineHeight: 1.6 }}>{item}</p>
              </div>
            ))}
          </div>
        </Section>

        <Section icon={BookOpen} title="Lessons Learned" accentColor={cs.accentColor}>
          <div className="flex flex-col gap-4">
            {cs.lessons.map((lesson, i) => (
              <div key={i} style={{ borderLeft: `3px solid ${cs.accentColor}22`, paddingLeft: 16 }}>
                <p style={{ fontSize: 14, color: SECONDARY, lineHeight: 1.75, fontStyle: "italic" }}>"{lesson}"</p>
              </div>
            ))}
          </div>
        </Section>

        {/* Disclaimer */}
        <div
          style={{
            backgroundColor: "#F7F7F5",
            border: `1px solid ${BORDER}`,
            borderRadius: 10,
            padding: "16px 18px",
            display: "flex",
            gap: 10,
            marginBottom: 40,
          }}
        >
          <Shield size={15} color={SECONDARY} style={{ flexShrink: 0, marginTop: 2 }} />
          <p style={{ fontSize: 12, color: SECONDARY, lineHeight: 1.65 }}>{cs.disclaimer}</p>
        </div>

        {/* Navigation */}
        <div className="flex flex-col sm:flex-row gap-4 justify-between">
          <Link
            to="/#work"
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: 6,
              color: NAVY,
              textDecoration: "none",
              fontSize: 14,
              fontWeight: 500,
              backgroundColor: CARD_BG,
              border: `1px solid ${BORDER}`,
              padding: "12px 20px",
              borderRadius: 7,
            }}
          >
            <ArrowLeft size={14} />
            All Case Studies
          </Link>
          {cs.nextSlug && (
            <Link
              to={`/case/${cs.nextSlug}`}
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: 6,
                color: "white",
                textDecoration: "none",
                fontSize: 14,
                fontWeight: 500,
                backgroundColor: cs.accentColor,
                padding: "12px 20px",
                borderRadius: 7,
              }}
            >
              Next: {cs.nextLabel}
              <ChevronRight size={14} />
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}

import { Link } from "react-router";
import {
  Download,
  ArrowRight,
  Users,
  Globe,
  TrendingUp,
  GraduationCap,
  Clock,
  Briefcase,
  Cpu,
  BarChart2,
  Building2,
  Zap,
  ChevronRight,
  ExternalLink,
  CheckCircle2,
  Award,
} from "lucide-react";
import { RecruiterConcierge } from "./RecruiterConcierge";

const NAVY = "#0B1D3A";
const TEAL = "#1A7A6E";
const TEAL_LIGHT = "#E8F5F2";
const CARBON = "#1C1C1E";
const SECONDARY = "#5A5A5A";
const BORDER = "#E4E4DF";
const CARD_BG = "#FFFFFF";
const PAGE_BG = "#FAFAF8";
const SECTION_BG = "#F4F4F1";

function TechPattern() {
  return (
    <svg
      style={{
        position: "absolute",
        top: 0,
        right: 0,
        width: "50%",
        height: "100%",
        opacity: 0.045,
        pointerEvents: "none",
      }}
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
          <path d="M 40 0 L 0 0 0 40" fill="none" stroke={NAVY} strokeWidth="0.8" />
        </pattern>
        <pattern id="dots" width="40" height="40" patternUnits="userSpaceOnUse">
          <circle cx="20" cy="20" r="1.5" fill={NAVY} />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#grid)" />
      <rect width="100%" height="100%" fill="url(#dots)" />
    </svg>
  );
}

function MetricCard({ value, label, icon: Icon }: { value: string; label: string; icon: React.ElementType }) {
  return (
    <div
      style={{
        backgroundColor: CARD_BG,
        border: `1px solid ${BORDER}`,
        borderRadius: 10,
        padding: "20px 22px",
        display: "flex",
        flexDirection: "column",
        gap: 6,
        flex: 1,
        minWidth: 130,
      }}
    >
      <Icon size={16} color={TEAL} />
      <div style={{ fontSize: 28, fontWeight: 700, color: NAVY, letterSpacing: "-0.02em", lineHeight: 1 }}>
        {value}
      </div>
      <div style={{ fontSize: 12, color: SECONDARY, fontWeight: 400, letterSpacing: "0.01em" }}>{label}</div>
    </div>
  );
}

function HeroSection() {
  return (
    <section
      id="hero"
      style={{
        backgroundColor: PAGE_BG,
        position: "relative",
        overflow: "hidden",
        paddingTop: 80,
        paddingBottom: 80,
      }}
    >
      <TechPattern />
      <div className="max-w-6xl mx-auto px-6 relative">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left: copy */}
          <div>
            <div
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: 8,
                backgroundColor: TEAL_LIGHT,
                border: `1px solid ${TEAL}22`,
                borderRadius: 20,
                padding: "5px 14px",
                fontSize: 12,
                fontWeight: 500,
                color: TEAL,
                letterSpacing: "0.03em",
                marginBottom: 24,
              }}
            >
              <span
                style={{
                  width: 6,
                  height: 6,
                  borderRadius: "50%",
                  backgroundColor: TEAL,
                  display: "inline-block",
                }}
              />
              Available · Remote · Hybrid · Madrid
            </div>

            <h1
              style={{
                fontSize: "clamp(36px, 5vw, 56px)",
                fontWeight: 800,
                color: NAVY,
                lineHeight: 1.1,
                letterSpacing: "-0.025em",
                marginBottom: 12,
              }}
            >
              Daniel Medina
              <br />
              Sánchez
            </h1>

            <div
              style={{
                fontSize: "clamp(16px, 2vw, 20px)",
                fontWeight: 600,
                color: TEAL,
                marginBottom: 16,
                letterSpacing: "-0.01em",
              }}
            >
              AI Transformation & Digital Operations Leader
            </div>

            <p
              style={{
                fontSize: 16,
                color: SECONDARY,
                lineHeight: 1.7,
                maxWidth: 520,
                marginBottom: 32,
              }}
            >
              I help organizations turn operational complexity into AI-enabled, measurable and governed work systems.
              Hybrid executive with 15+ years across Digital Workplace, Public Sector, ITSM and large-scale operations.
            </p>

            <div className="flex flex-wrap gap-3 mb-10">
              <a
                href="#"
                style={{
                  backgroundColor: NAVY,
                  color: "white",
                  padding: "12px 22px",
                  borderRadius: 6,
                  fontSize: 14,
                  fontWeight: 500,
                  textDecoration: "none",
                  display: "flex",
                  alignItems: "center",
                  gap: 7,
                }}
              >
                <Download size={14} />
                Download CV
              </a>
              <a
                href="#work"
                onClick={(e) => {
                  e.preventDefault();
                  document.getElementById("work")?.scrollIntoView({ behavior: "smooth" });
                }}
                style={{
                  backgroundColor: "transparent",
                  color: NAVY,
                  padding: "12px 22px",
                  borderRadius: 6,
                  fontSize: 14,
                  fontWeight: 500,
                  textDecoration: "none",
                  display: "flex",
                  alignItems: "center",
                  gap: 7,
                  border: `1.5px solid ${NAVY}`,
                }}
              >
                View Case Studies
                <ArrowRight size={14} />
              </a>
              <a
                href="mailto:Danielmedinasanchez86@gmail.com"
                style={{
                  backgroundColor: TEAL_LIGHT,
                  color: TEAL,
                  padding: "12px 22px",
                  borderRadius: 6,
                  fontSize: 14,
                  fontWeight: 500,
                  textDecoration: "none",
                  border: `1px solid ${TEAL}33`,
                }}
              >
                Book Interview
              </a>
            </div>

            {/* Trust bar */}
            <div
              style={{
                borderTop: `1px solid ${BORDER}`,
                paddingTop: 20,
              }}
            >
              <div style={{ fontSize: 11, color: "#9A9A9A", letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 12, fontWeight: 500 }}>
                Experience & Credentials
              </div>
              <div className="flex flex-wrap gap-x-6 gap-y-2">
                {["Ayesa", "Konecta", "HarvardX CS50", "TransformIA AI Lab", "ENEB MBA"].map((org) => (
                  <span key={org} style={{ fontSize: 13, color: SECONDARY, fontWeight: 500 }}>
                    {org}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Right: floating metric cards */}
          <div className="hidden lg:block relative">
            <div
              style={{
                position: "relative",
                height: 440,
              }}
            >
              {/* Central card */}
              <div
                style={{
                  position: "absolute",
                  top: "50%",
                  left: "50%",
                  transform: "translate(-50%,-50%)",
                  backgroundColor: NAVY,
                  color: "white",
                  borderRadius: 16,
                  padding: "28px 32px",
                  width: 220,
                  boxShadow: "0 20px 60px rgba(11,29,58,0.25)",
                  zIndex: 3,
                }}
              >
                <div style={{ fontSize: 11, color: "rgba(255,255,255,0.5)", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: 16 }}>
                  Profile
                </div>
                <div style={{ fontSize: 22, fontWeight: 700, marginBottom: 4 }}>Daniel Medina</div>
                <div style={{ fontSize: 13, color: "rgba(255,255,255,0.7)", marginBottom: 16, lineHeight: 1.4 }}>
                  AI Transformation & Digital Operations Leader
                </div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                  {["AI Transformation", "ITSM", "HITL"].map((tag) => (
                    <span
                      key={tag}
                      style={{
                        backgroundColor: "rgba(255,255,255,0.1)",
                        border: "1px solid rgba(255,255,255,0.15)",
                        borderRadius: 4,
                        padding: "3px 8px",
                        fontSize: 10,
                        color: "rgba(255,255,255,0.75)",
                        fontWeight: 500,
                      }}
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              {/* Top-left: Years */}
              <div
                style={{
                  position: "absolute",
                  top: 20,
                  left: 0,
                  backgroundColor: CARD_BG,
                  border: `1px solid ${BORDER}`,
                  borderRadius: 12,
                  padding: "18px 20px",
                  boxShadow: "0 4px 20px rgba(0,0,0,0.06)",
                  zIndex: 2,
                }}
              >
                <div style={{ fontSize: 32, fontWeight: 800, color: NAVY, letterSpacing: "-0.03em" }}>15+</div>
                <div style={{ fontSize: 12, color: SECONDARY }}>Years Experience</div>
              </div>

              {/* Top-right: People */}
              <div
                style={{
                  position: "absolute",
                  top: 30,
                  right: 0,
                  backgroundColor: CARD_BG,
                  border: `1px solid ${BORDER}`,
                  borderRadius: 12,
                  padding: "18px 20px",
                  boxShadow: "0 4px 20px rgba(0,0,0,0.06)",
                  zIndex: 2,
                }}
              >
                <div style={{ fontSize: 32, fontWeight: 800, color: NAVY, letterSpacing: "-0.03em" }}>560+</div>
                <div style={{ fontSize: 12, color: SECONDARY }}>People Led</div>
              </div>

              {/* Bottom-left: P&L */}
              <div
                style={{
                  position: "absolute",
                  bottom: 40,
                  left: 10,
                  backgroundColor: TEAL,
                  borderRadius: 12,
                  padding: "18px 20px",
                  boxShadow: "0 4px 20px rgba(26,122,110,0.3)",
                  zIndex: 2,
                }}
              >
                <div style={{ fontSize: 28, fontWeight: 800, color: "white", letterSpacing: "-0.03em" }}>€12M+</div>
                <div style={{ fontSize: 12, color: "rgba(255,255,255,0.8)" }}>P&L Managed</div>
              </div>

              {/* Bottom-right: Countries */}
              <div
                style={{
                  position: "absolute",
                  bottom: 60,
                  right: 10,
                  backgroundColor: CARD_BG,
                  border: `1px solid ${BORDER}`,
                  borderRadius: 12,
                  padding: "18px 20px",
                  boxShadow: "0 4px 20px rgba(0,0,0,0.06)",
                  zIndex: 2,
                }}
              >
                <div style={{ fontSize: 32, fontWeight: 800, color: NAVY, letterSpacing: "-0.03em" }}>3</div>
                <div style={{ fontSize: 12, color: SECONDARY }}>Countries</div>
              </div>

              {/* CS50 badge */}
              <div
                style={{
                  position: "absolute",
                  bottom: 0,
                  left: "50%",
                  transform: "translateX(-50%)",
                  backgroundColor: "#FFF8E7",
                  border: "1px solid #F0D080",
                  borderRadius: 8,
                  padding: "10px 16px",
                  display: "flex",
                  alignItems: "center",
                  gap: 8,
                  whiteSpace: "nowrap",
                  zIndex: 4,
                }}
              >
                <GraduationCap size={14} color="#B8860B" />
                <span style={{ fontSize: 12, fontWeight: 600, color: "#7A5C00" }}>HarvardX CS50x + CS50AI</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function MetricsSection() {
  const metrics = [
    { value: "15+", label: "Years Experience", icon: Clock },
    { value: "560+", label: "People Led", icon: Users },
    { value: "3", label: "Countries", icon: Globe },
    { value: "€12M+", label: "P&L Managed", icon: TrendingUp },
    { value: "CS50x+AI", label: "HarvardX", icon: GraduationCap },
  ];

  return (
    <section
      style={{
        backgroundColor: NAVY,
        padding: "40px 0",
      }}
    >
      <div className="max-w-6xl mx-auto px-6">
        <div className="flex flex-wrap gap-4 justify-between">
          {metrics.map((m) => (
            <div key={m.label} className="flex items-center gap-4 flex-1" style={{ minWidth: 140 }}>
              <m.icon size={20} color="rgba(255,255,255,0.4)" />
              <div>
                <div style={{ fontSize: 26, fontWeight: 800, color: "white", letterSpacing: "-0.02em", lineHeight: 1 }}>
                  {m.value}
                </div>
                <div style={{ fontSize: 12, color: "rgba(255,255,255,0.5)", marginTop: 2, fontWeight: 400 }}>{m.label}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function ValueAreasSection() {
  const areas = [
    {
      icon: Cpu,
      title: "AI Transformation",
      tags: ["GenAI Adoption", "Human-in-the-Loop", "AI Enablement", "Workflow Automation", "AI Literacy"],
    },
    {
      icon: Briefcase,
      title: "Digital Workplace / ITSM",
      tags: ["Modern Workplace", "Atlassian JSM", "Service Workflows", "User Experience", "Public Sector"],
    },
    {
      icon: BarChart2,
      title: "Operations Leadership",
      tags: ["P&L Management", "SLA/KPI Governance", "CX & Contact Center", "Service Delivery", "Process Redesign"],
    },
    {
      icon: Building2,
      title: "Public Sector Delivery",
      tags: ["Gov't Transformation", "Executive Docs", "Stakeholder Mgmt", "Compliance", "Coordination"],
    },
    {
      icon: Zap,
      title: "Human-in-the-Loop / AI Enablement",
      tags: ["HITL Design", "Governance", "AI Oversight", "Responsible AI", "Workflow Orchestration"],
    },
  ];

  return (
    <section
      id="value"
      style={{
        backgroundColor: SECTION_BG,
        padding: "72px 0",
        borderTop: `1px solid ${BORDER}`,
        borderBottom: `1px solid ${BORDER}`,
      }}
    >
      <div className="max-w-6xl mx-auto px-6">
        <div className="mb-10">
          <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.14em", color: TEAL, textTransform: "uppercase", marginBottom: 10 }}>
            Core Value Areas
          </div>
          <h2 style={{ fontSize: 32, fontWeight: 700, color: NAVY, letterSpacing: "-0.02em" }}>
            Where I deliver impact
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {areas.map((area) => (
            <div
              key={area.title}
              style={{
                backgroundColor: CARD_BG,
                border: `1px solid ${BORDER}`,
                borderRadius: 10,
                padding: "24px 22px",
              }}
            >
              <div
                style={{
                  width: 40,
                  height: 40,
                  borderRadius: 8,
                  backgroundColor: TEAL_LIGHT,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  marginBottom: 14,
                }}
              >
                <area.icon size={18} color={TEAL} />
              </div>
              <h3 style={{ fontSize: 15, fontWeight: 600, color: CARBON, marginBottom: 12 }}>{area.title}</h3>
              <div className="flex flex-wrap gap-2">
                {area.tags.map((tag) => (
                  <span
                    key={tag}
                    style={{
                      backgroundColor: "#F0F0ED",
                      borderRadius: 4,
                      padding: "3px 9px",
                      fontSize: 11,
                      color: SECONDARY,
                      fontWeight: 400,
                    }}
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function CaseStudiesSection() {
  const cases = [
    {
      slug: "ayesa",
      org: "Ayesa",
      period: "Aug 2025 – Dec 2025",
      role: "AI Strategy & Digital Workplace Architect | Project Manager",
      description:
        "Led digital transformation, Modern Workplace and applied AI for the public sector. Projects linked to Madrid Digital, Justice, UOC and ICEX.",
      tags: ["Digital Workplace", "ITSM", "Public Sector", "Atlassian JSM"],
      highlight: "ICEX project delivered as PM with full coordination, tracking and client validation.",
      color: NAVY,
    },
    {
      slug: "konecta",
      org: "Konecta",
      period: "Apr 2023 – Aug 2025",
      role: "Business Manager · General Service Lead",
      description:
        "General Service Lead for Liberty Seguros. Directed 560+ people across Spain, Portugal and Colombia with €12M+ P&L responsibility.",
      tags: ["Operations at Scale", "P&L", "CX", "Insurance"],
      highlight: "560 people · 3 countries · €12M+ P&L · SLA/KPI governance.",
      color: "#1E3A5F",
    },
    {
      slug: "transformia",
      org: "TransformIA AI Lab",
      period: "Ongoing",
      role: "Founder · HITL Operator · AI Workflow Architect",
      description:
        "Personal AI Lab demonstrating practical enterprise AI: automation, Human-in-the-Loop, eWorkers, Digital Workplace and operational governance.",
      tags: ["Human-in-the-Loop", "AI Workflows", "Governance", "n8n · Codex"],
      highlight: "Public-safe architecture. Proof of work for AI Transformation roles.",
      color: TEAL,
    },
    {
      slug: "harvardx",
      org: "HarvardX CS50",
      period: "2024 – 2025",
      role: "Applied Learner · Technical AI Foundation",
      description:
        "CS50x + CS50AI. 10 problem sets, final project, 12 Python AI projects. C, Python, SQL, algorithms, ML, neural networks, NLP.",
      tags: ["CS50x", "CS50AI", "Python", "Machine Learning"],
      highlight: "Technical foundation for business-AI translation.",
      color: "#7A5C00",
    },
  ];

  return (
    <section id="work" style={{ backgroundColor: PAGE_BG, padding: "80px 0" }}>
      <div className="max-w-6xl mx-auto px-6">
        <div className="mb-10">
          <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.14em", color: TEAL, textTransform: "uppercase", marginBottom: 10 }}>
            Selected Case Studies
          </div>
          <div className="flex items-end justify-between flex-wrap gap-4">
            <h2 style={{ fontSize: 32, fontWeight: 700, color: NAVY, letterSpacing: "-0.02em" }}>
              Evidence of impact
            </h2>
            <span style={{ fontSize: 13, color: SECONDARY }}>Public-safe · No private code · No real client data</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {cases.map((c) => (
            <Link
              key={c.slug}
              to={`/case/${c.slug}`}
              style={{ textDecoration: "none" }}
            >
              <div
                style={{
                  backgroundColor: CARD_BG,
                  border: `1px solid ${BORDER}`,
                  borderRadius: 12,
                  overflow: "hidden",
                  transition: "box-shadow 0.2s, transform 0.2s",
                  cursor: "pointer",
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLElement).style.boxShadow = "0 8px 32px rgba(11,29,58,0.1)";
                  (e.currentTarget as HTMLElement).style.transform = "translateY(-2px)";
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLElement).style.boxShadow = "none";
                  (e.currentTarget as HTMLElement).style.transform = "translateY(0)";
                }}
              >
                {/* Card header */}
                <div
                  style={{
                    backgroundColor: c.color,
                    padding: "22px 24px",
                  }}
                >
                  <div
                    style={{
                      display: "inline-block",
                      backgroundColor: "rgba(255,255,255,0.15)",
                      borderRadius: 4,
                      padding: "3px 10px",
                      fontSize: 11,
                      color: "rgba(255,255,255,0.8)",
                      marginBottom: 10,
                      fontWeight: 500,
                      letterSpacing: "0.04em",
                    }}
                  >
                    {c.period}
                  </div>
                  <div style={{ fontSize: 22, fontWeight: 700, color: "white", letterSpacing: "-0.01em" }}>
                    {c.org}
                  </div>
                  <div style={{ fontSize: 13, color: "rgba(255,255,255,0.7)", marginTop: 4 }}>{c.role}</div>
                </div>

                {/* Card body */}
                <div style={{ padding: "20px 24px" }}>
                  <p style={{ fontSize: 14, color: SECONDARY, lineHeight: 1.65, marginBottom: 14 }}>{c.description}</p>

                  <div
                    style={{
                      backgroundColor: TEAL_LIGHT,
                      border: `1px solid ${TEAL}22`,
                      borderRadius: 6,
                      padding: "10px 14px",
                      marginBottom: 14,
                    }}
                  >
                    <div style={{ fontSize: 12, color: TEAL, fontWeight: 500 }}>{c.highlight}</div>
                  </div>

                  <div className="flex flex-wrap gap-2 mb-4">
                    {c.tags.map((tag) => (
                      <span
                        key={tag}
                        style={{
                          backgroundColor: "#F0F0ED",
                          borderRadius: 4,
                          padding: "3px 9px",
                          fontSize: 11,
                          color: SECONDARY,
                        }}
                      >
                        {tag}
                      </span>
                    ))}
                  </div>

                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: 5,
                      fontSize: 13,
                      fontWeight: 500,
                      color: NAVY,
                    }}
                  >
                    View Case Study <ChevronRight size={14} />
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}

function ProofOfWorkSection() {
  const items = [
    { label: "Human-in-the-Loop AI workflow design" },
    { label: "Public-safe architecture" },
    { label: "Recruiter concierge demo" },
    { label: "Documentation & executive delivery" },
    { label: "n8n · Codex · GitHub · Figma" },
    { label: "AI eWorkers & automation" },
  ];

  return (
    <section
      id="lab"
      style={{
        backgroundColor: SECTION_BG,
        padding: "80px 0",
        borderTop: `1px solid ${BORDER}`,
      }}
    >
      <div className="max-w-6xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left */}
          <div>
            <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.14em", color: TEAL, textTransform: "uppercase", marginBottom: 10 }}>
              Proof of Work
            </div>
            <h2 style={{ fontSize: 32, fontWeight: 700, color: NAVY, letterSpacing: "-0.02em", marginBottom: 16 }}>
              TransformIA AI Lab
            </h2>
            <p style={{ fontSize: 16, color: SECONDARY, lineHeight: 1.7, marginBottom: 20 }}>
              Personal AI Lab designed to demonstrate practical enterprise AI: automation, Human-in-the-Loop, eWorkers,
              Digital Workplace, intelligent documentation and operational governance.
            </p>
            <p style={{ fontSize: 15, color: SECONDARY, lineHeight: 1.7, marginBottom: 28 }}>
              Public-safe portfolio showing how to turn business intent into working systems with AI, human oversight and evidence.
            </p>
            <div className="grid grid-cols-2 gap-3 mb-8">
              {items.map((item) => (
                <div key={item.label} className="flex items-start gap-2">
                  <CheckCircle2 size={15} color={TEAL} style={{ flexShrink: 0, marginTop: 2 }} />
                  <span style={{ fontSize: 13, color: CARBON }}>{item.label}</span>
                </div>
              ))}
            </div>
            <div className="flex gap-3">
              <div
                style={{
                  backgroundColor: NAVY,
                  color: "white",
                  padding: "10px 20px",
                  borderRadius: 6,
                  fontSize: 13,
                  fontWeight: 500,
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 7,
                }}
              >
                GitHub · public-safe soon <ExternalLink size={12} />
              </div>
            </div>
          </div>

          {/* Right: visual */}
          <div>
            <div
              style={{
                backgroundColor: NAVY,
                borderRadius: 16,
                padding: "32px",
                boxShadow: "0 20px 60px rgba(11,29,58,0.2)",
              }}
            >
              <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: 24 }}>
                TransformIA AI Lab · Architecture
              </div>

              {[
                { step: "01", label: "Business Intent", desc: "Define goals, constraints and governance rules" },
                { step: "02", label: "AI Workflow Design", desc: "Build automation with human checkpoints" },
                { step: "03", label: "Human-in-the-Loop Gate", desc: "Every sensitive action requires explicit approval" },
                { step: "04", label: "Evidence & Delivery", desc: "Documented output, traceable and measurable" },
              ].map((item, i) => (
                <div key={item.step} className="flex gap-4 mb-5 last:mb-0">
                  <div
                    style={{
                      width: 32,
                      height: 32,
                      borderRadius: 6,
                      backgroundColor: i === 2 ? TEAL : "rgba(255,255,255,0.1)",
                      border: i === 2 ? "none" : "1px solid rgba(255,255,255,0.15)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      fontSize: 10,
                      fontWeight: 700,
                      color: "rgba(255,255,255,0.8)",
                      flexShrink: 0,
                    }}
                  >
                    {item.step}
                  </div>
                  <div>
                    <div style={{ fontSize: 14, fontWeight: 600, color: "white", marginBottom: 2 }}>{item.label}</div>
                    <div style={{ fontSize: 12, color: "rgba(255,255,255,0.55)" }}>{item.desc}</div>
                  </div>
                </div>
              ))}

              <div
                style={{
                  marginTop: 28,
                  paddingTop: 20,
                  borderTop: "1px solid rgba(255,255,255,0.08)",
                  display: "flex",
                  flexWrap: "wrap",
                  gap: 8,
                }}
              >
                {["n8n", "Codex", "GitHub", "Figma", "Python", "RAG"].map((tool) => (
                  <span
                    key={tool}
                    style={{
                      backgroundColor: "rgba(255,255,255,0.08)",
                      border: "1px solid rgba(255,255,255,0.12)",
                      borderRadius: 4,
                      padding: "4px 10px",
                      fontSize: 11,
                      color: "rgba(255,255,255,0.7)",
                      fontWeight: 500,
                    }}
                  >
                    {tool}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function CredentialsSection() {
  return (
    <section
      id="credentials"
      style={{
        backgroundColor: PAGE_BG,
        padding: "80px 0",
        borderTop: `1px solid ${BORDER}`,
      }}
    >
      <div className="max-w-6xl mx-auto px-6">
        <div className="mb-10">
          <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.14em", color: TEAL, textTransform: "uppercase", marginBottom: 10 }}>
            Education & Certifications
          </div>
          <h2 style={{ fontSize: 32, fontWeight: 700, color: NAVY, letterSpacing: "-0.02em" }}>
            Credentials
          </h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Featured: HarvardX */}
          <div
            className="lg:col-span-1"
            style={{
              backgroundColor: "#FFFBEF",
              border: "1.5px solid #E8C84A",
              borderRadius: 12,
              padding: "28px 26px",
              position: "relative",
              overflow: "hidden",
            }}
          >
            <div
              style={{
                position: "absolute",
                top: 0,
                right: 0,
                backgroundColor: "#E8C84A",
                color: "#5A3E00",
                fontSize: 10,
                fontWeight: 700,
                padding: "4px 12px",
                borderBottomLeftRadius: 8,
                letterSpacing: "0.08em",
                textTransform: "uppercase",
              }}
            >
              Featured
            </div>
            <GraduationCap size={28} color="#B8860B" style={{ marginBottom: 14 }} />
            <div style={{ fontSize: 12, color: "#8A6800", fontWeight: 600, letterSpacing: "0.04em", marginBottom: 4 }}>
              HarvardX · CS50
            </div>
            <h3 style={{ fontSize: 18, fontWeight: 700, color: "#3A2800", marginBottom: 10, lineHeight: 1.3 }}>
              Computer Science for Artificial Intelligence
            </h3>
            <p style={{ fontSize: 13, color: "#6A5000", lineHeight: 1.65, marginBottom: 14 }}>
              CS50x + CS50AI · 10 problem sets + final project · 12 Python AI projects
            </p>
            <div className="flex flex-wrap gap-2">
              {["C", "Python", "SQL", "Algorithms", "ML", "Neural Networks", "NLP"].map((tag) => (
                <span
                  key={tag}
                  style={{
                    backgroundColor: "#FFF0A0",
                    borderRadius: 4,
                    padding: "3px 8px",
                    fontSize: 11,
                    color: "#7A5C00",
                    fontWeight: 500,
                  }}
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>

          {/* Right: other credentials */}
          <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
            {[
              {
                icon: Award,
                org: "ENEB",
                title: "MBA in Business Administration and Management",
                detail: "Grade: 9.58 / 10",
              },
              {
                icon: GraduationCap,
                org: "Universidad Rey Juan Carlos",
                title: "University Diploma in Labour Relations",
                detail: "",
              },
              {
                icon: Cpu,
                org: "SEPE",
                title: "Machine Learning and Artificial Intelligence",
                detail: "IFCD077PO · 200 hours",
              },
              {
                icon: Zap,
                org: "SEPE",
                title: "Agile Management",
                detail: "ADGD46 · 60 hours",
              },
              {
                icon: BarChart2,
                org: "SEPE",
                title: "Digital Marketing & Automation Marketing",
                detail: "COMM27 · 60 hours",
              },
              {
                icon: Cpu,
                org: "Microsoft",
                title: "Microsoft AI Skills Fest 2026",
                detail: "AI Transformation",
              },
            ].map((cred) => (
              <div
                key={cred.title}
                style={{
                  backgroundColor: CARD_BG,
                  border: `1px solid ${BORDER}`,
                  borderRadius: 10,
                  padding: "18px 18px",
                }}
              >
                <cred.icon size={16} color={TEAL} style={{ marginBottom: 10 }} />
                <div style={{ fontSize: 11, color: SECONDARY, fontWeight: 500, marginBottom: 4 }}>{cred.org}</div>
                <div style={{ fontSize: 13, fontWeight: 600, color: CARBON, lineHeight: 1.4, marginBottom: 4 }}>
                  {cred.title}
                </div>
                {cred.detail && (
                  <div style={{ fontSize: 12, color: SECONDARY }}>{cred.detail}</div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Skills grid */}
        <div className="mt-10 grid grid-cols-1 md:grid-cols-3 gap-5">
          {[
            {
              category: "AI & Technical Literacy",
              skills: "Generative AI · Prompt engineering · Python · C · SQL · JavaScript basics · Git · GitHub · Workflow automation · RAG concepts · AI evaluation",
            },
            {
              category: "Delivery & Transformation",
              skills: "Project Management · Digital Workplace · Modern Workplace · ITSM · Atlassian JSM · Stakeholder management · Public sector transformation · Change & adoption",
            },
            {
              category: "Operations & Business",
              skills: "P&L management · SLA/KPI governance · Contact Center · CX · Service Delivery · Insurance operations · Team leadership · Forecasting · Client governance",
            },
          ].map((s) => (
            <div
              key={s.category}
              style={{
                backgroundColor: CARD_BG,
                border: `1px solid ${BORDER}`,
                borderRadius: 10,
                padding: "20px 20px",
              }}
            >
              <div
                style={{
                  fontSize: 11,
                  fontWeight: 700,
                  color: TEAL,
                  letterSpacing: "0.1em",
                  textTransform: "uppercase",
                  marginBottom: 10,
                }}
              >
                {s.category}
              </div>
              <p style={{ fontSize: 13, color: SECONDARY, lineHeight: 1.7 }}>{s.skills}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function ContactSection() {
  return (
    <section
      id="contact"
      style={{
        backgroundColor: NAVY,
        padding: "80px 0",
        position: "relative",
        overflow: "hidden",
      }}
    >
      {/* Subtle background pattern */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          backgroundImage: `radial-gradient(circle at 80% 50%, rgba(26,122,110,0.15) 0%, transparent 60%)`,
          pointerEvents: "none",
        }}
      />
      <div className="max-w-6xl mx-auto px-6 relative">
        <div className="max-w-2xl">
          <div
            style={{
              fontSize: 11,
              fontWeight: 600,
              letterSpacing: "0.14em",
              color: "rgba(26,122,110,0.9)",
              textTransform: "uppercase",
              marginBottom: 14,
            }}
          >
            Open to Opportunities
          </div>
          <h2
            style={{
              fontSize: "clamp(28px, 4vw, 42px)",
              fontWeight: 700,
              color: "white",
              letterSpacing: "-0.02em",
              lineHeight: 1.2,
              marginBottom: 16,
            }}
          >
            Available for senior roles in AI Transformation & Digital Operations
          </h2>
          <p style={{ fontSize: 16, color: "rgba(255,255,255,0.65)", lineHeight: 1.7, marginBottom: 32, maxWidth: 520 }}>
            Remote · Hybrid · Madrid-based. Looking for AI Project Manager, AI Transformation Lead, Digital Workplace,
            ITSM, Operations and Public Sector roles.
          </p>

          <div className="flex flex-wrap gap-3">
            <a
              href="mailto:Danielmedinasanchez86@gmail.com"
              style={{
                backgroundColor: TEAL,
                color: "white",
                padding: "13px 24px",
                borderRadius: 6,
                fontSize: 14,
                fontWeight: 500,
                textDecoration: "none",
                display: "inline-flex",
                alignItems: "center",
                gap: 8,
              }}
            >
              Book an Interview →
            </a>
            <a
              href="#"
              style={{
                backgroundColor: "rgba(255,255,255,0.1)",
                border: "1px solid rgba(255,255,255,0.2)",
                color: "white",
                padding: "13px 24px",
                borderRadius: 6,
                fontSize: 14,
                fontWeight: 500,
                textDecoration: "none",
                display: "inline-flex",
                alignItems: "center",
                gap: 8,
              }}
            >
              <Download size={14} />
              Download CV
            </a>
            <a
              href="https://linkedin.com/in/danielmedina-ai"
              target="_blank"
              rel="noopener noreferrer"
              style={{
                backgroundColor: "rgba(255,255,255,0.1)",
                border: "1px solid rgba(255,255,255,0.2)",
                color: "white",
                padding: "13px 24px",
                borderRadius: 6,
                fontSize: 14,
                fontWeight: 500,
                textDecoration: "none",
                display: "inline-flex",
                alignItems: "center",
                gap: 8,
              }}
            >
              LinkedIn <ExternalLink size={12} />
            </a>
          </div>

          <div
            style={{
              marginTop: 40,
              display: "flex",
              flexWrap: "wrap",
              gap: 20,
            }}
          >
            {[
              { label: "Email", value: "Danielmedinasanchez86@gmail.com" },
              { label: "Phone", value: "+34 646 285 942" },
              { label: "LinkedIn", value: "linkedin.com/in/danielmedina-ai" },
            ].map((c) => (
              <div key={c.label}>
                <div style={{ fontSize: 10, color: "rgba(255,255,255,0.35)", fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 3 }}>
                  {c.label}
                </div>
                <div style={{ fontSize: 13, color: "rgba(255,255,255,0.75)" }}>{c.value}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

export function HomePage() {
  return (
    <div>
      <HeroSection />
      <MetricsSection />
      <ValueAreasSection />
      <CaseStudiesSection />
      <ProofOfWorkSection />
      <section id="concierge" style={{ backgroundColor: PAGE_BG, padding: "80px 0", borderTop: `1px solid ${BORDER}` }}>
        <div className="max-w-6xl mx-auto px-6">
          <div className="mb-10">
            <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.14em", color: TEAL, textTransform: "uppercase", marginBottom: 10 }}>
              Recruiter Concierge
            </div>
            <div className="flex items-end justify-between flex-wrap gap-4">
              <h2 style={{ fontSize: 32, fontWeight: 700, color: NAVY, letterSpacing: "-0.02em" }}>
                Ask about Daniel's profile
              </h2>
              <div
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 6,
                  backgroundColor: TEAL_LIGHT,
                  border: `1px solid ${TEAL}33`,
                  borderRadius: 20,
                  padding: "5px 12px",
                  fontSize: 11,
                  color: TEAL,
                  fontWeight: 500,
                }}
              >
                <span style={{ width: 6, height: 6, borderRadius: "50%", backgroundColor: TEAL, display: "inline-block" }} />
                Human-in-the-Loop · All actions require approval
              </div>
            </div>
          </div>
          <RecruiterConcierge />
        </div>
      </section>
      <CredentialsSection />
      <ContactSection />
    </div>
  );
}

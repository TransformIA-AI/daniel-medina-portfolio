import { Outlet, ScrollRestoration } from "react-router";
import { Nav } from "./Nav";
import { Footer } from "./Footer";

export function Root() {
  return (
    <div
      className="min-h-screen"
      style={{
        backgroundColor: "#FAFAF8",
        fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif",
        color: "#1C1C1E",
      }}
    >
      <ScrollRestoration />
      <Nav />
      <main>
        <Outlet />
      </main>
      <Footer />
    </div>
  );
}

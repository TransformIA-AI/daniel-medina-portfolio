import { useState } from "react";
import { Send, User, Bot, CheckCircle2, Clock, Star, Shield, Calendar, Download, ChevronDown } from "lucide-react";

const NAVY = "#0B1D3A";
const TEAL = "#1A7A6E";
const TEAL_LIGHT = "#E8F5F2";
const SECONDARY = "#5A5A5A";
const BORDER = "#E4E4DF";
const CARD_BG = "#FFFFFF";

const SUGGESTED = [
  "Is Daniel a fit for an AI Transformation Project Manager role?",
  "What is Daniel's experience with public sector delivery?",
  "Tell me about Daniel's operations leadership at Konecta",
  "What technical skills does Daniel have for AI roles?",
  "Is Daniel available for remote work?",
  "What is Daniel's Human-in-the-Loop experience?",
];

type Message = {
  role: "user" | "assistant";
  content: string;
  fitScore?: number;
  cvRecommended?: string;
  actions?: string[];
};

const RESPONSES: Record<string, Message> = {
  default_fit: {
    role: "assistant",
    content:
      "Strong fit. Evidence: public sector delivery at Ayesa (ICEX, Madrid Digital, Justice, UOC), large-scale operations at Konecta (560 people, 3 countries, €12M+ P&L), HarvardX CS50x + CS50AI technical foundation, TransformIA AI Lab with HITL workflow architecture.",
    fitScore: 86,
    cvRecommended: "AI Transformation / Digital Operations CV",
    actions: ["Request interview · Pending Daniel approval"],
  },
  public_sector: {
    role: "assistant",
    content:
      "Demonstrated public sector delivery at Ayesa (Aug–Dec 2025): projects linked to Madrid Digital, Ministerio de Justicia, UOC and ICEX. Led ICEX project as PM with full coordination, tracking, validation and client delivery. Atlassian Jira Service Management implementation for public sector ITSM.",
    fitScore: 82,
    cvRecommended: "Digital Workplace / ITSM CV",
    actions: ["View Ayesa case study", "Request interview · Pending Daniel approval"],
  },
  konecta: {
    role: "assistant",
    content:
      "At Konecta (Apr 2023 – Aug 2025), Daniel was General Service Lead for Liberty Seguros. Directed up to 560 people across Spain, Portugal and Colombia. Full P&L responsibility above €12M. Managed inbound and outbound sales, post-sales, retention, collections, SLA/KPI governance and weekly executive reporting.",
    fitScore: 90,
    cvRecommended: "Operations Leadership CV",
    actions: ["View Konecta case study", "Request interview · Pending Daniel approval"],
  },
  technical: {
    role: "assistant",
    content:
      "Technical foundation: HarvardX CS50x (C, Python, SQL, algorithms, data structures, search) + CS50AI (ML, neural networks, NLP, 12 Python AI projects). Applied skills: prompt engineering, workflow automation, RAG concepts, AI evaluation, n8n, GitHub, Codex. Business-AI translation specialist.",
    fitScore: 78,
    cvRecommended: "AI Transformation CV",
    actions: ["View HarvardX case study", "Request interview · Pending Daniel approval"],
  },
  availability: {
    role: "assistant",
    content:
      "Daniel is currently available. Open to: Remote · Hybrid · Madrid-based roles. Target roles: AI Transformation Project Manager, AI Enablement Lead, Digital Workplace Architect, ITSM Consultant, Operations Transformation, Public Sector Delivery. Contact: Danielmedinasanchez86@gmail.com · +34 646 285 942",
    fitScore: 95,
    cvRecommended: "AI Transformation / Digital Operations CV",
    actions: ["Book interview · Pending Daniel approval", "Download CV"],
  },
  hitl: {
    role: "assistant",
    content:
      "Human-in-the-Loop is a core design principle in Daniel's TransformIA AI Lab. All AI workflows include explicit human approval gates for sensitive actions. Architecture: Business intent → AI workflow → HITL gate → Evidence & delivery. No autonomous action without human sign-off. This is demonstrated in the Recruiter Concierge itself.",
    fitScore: 88,
    cvRecommended: "AI Transformation CV",
    actions: ["View TransformIA case study", "Request interview · Pending Daniel approval"],
  },
};

function getResponse(input: string): Message {
  const lower = input.toLowerCase();
  if (lower.includes("ai transformation") || lower.includes("project manager") || lower.includes("fit")) {
    return RESPONSES.default_fit;
  }
  if (lower.includes("public sector") || lower.includes("ayesa") || lower.includes("government")) {
    return RESPONSES.public_sector;
  }
  if (lower.includes("konecta") || lower.includes("operations") || lower.includes("p&l") || lower.includes("people")) {
    return RESPONSES.konecta;
  }
  if (lower.includes("technical") || lower.includes("cs50") || lower.includes("python") || lower.includes("ai skill")) {
    return RESPONSES.technical;
  }
  if (lower.includes("available") || lower.includes("remote") || lower.includes("hire")) {
    return RESPONSES.availability;
  }
  if (lower.includes("human") || lower.includes("hitl") || lower.includes("loop") || lower.includes("governance")) {
    return RESPONSES.hitl;
  }
  return RESPONSES.default_fit;
}

function FitScoreMeter({ score }: { score: number }) {
  const pct = score / 100;
  const r = 40;
  const circ = 2 * Math.PI * r;
  const dash = circ * pct;
  const color = score >= 85 ? TEAL : score >= 70 ? "#C8A020" : "#D44040";

  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
      <div style={{ position: "relative", width: 96, height: 96 }}>
        <svg width="96" height="96" viewBox="0 0 96 96">
          <circle cx="48" cy="48" r={r} fill="none" stroke="#F0F0ED" strokeWidth="7" />
          <circle
            cx="48"
            cy="48"
            r={r}
            fill="none"
            stroke={color}
            strokeWidth="7"
            strokeDasharray={`${dash} ${circ}`}
            strokeLinecap="round"
            transform="rotate(-90 48 48)"
            style={{ transition: "stroke-dasharray 1s ease" }}
          />
        </svg>
        <div
          style={{
            position: "absolute",
            inset: 0,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <div style={{ fontSize: 22, fontWeight: 800, color: color, letterSpacing: "-0.02em", lineHeight: 1 }}>
            {score}
          </div>
          <div style={{ fontSize: 10, color: SECONDARY }}>/ 100</div>
        </div>
      </div>
      <div style={{ fontSize: 12, fontWeight: 600, color: SECONDARY }}>Fit Score</div>
    </div>
  );
}

export function RecruiterConcierge() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content:
        "Hello. I'm the TransformIA Recruiter Concierge. I can answer questions about Daniel Medina Sánchez's professional profile based on his public portfolio, CV and case studies. All interview or calendar actions require Daniel's explicit approval. How can I help?",
    },
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [pendingApproval, setPendingApproval] = useState(false);
  const [showDisclaimer, setShowDisclaimer] = useState(true);

  const send = (text?: string) => {
    const q = text ?? input.trim();
    if (!q) return;
    setInput("");
    setMessages((prev) => [...prev, { role: "user", content: q }]);
    setIsTyping(true);
    setTimeout(() => {
      setIsTyping(false);
      const reply = getResponse(q);
      setMessages((prev) => [...prev, reply]);
    }, 1100);
  };

  const handleAction = (action: string) => {
    if (action.toLowerCase().includes("interview") || action.toLowerCase().includes("book")) {
      setPendingApproval(true);
    }
  };

  const lastAssistantMessage = [...messages].reverse().find((m) => m.role === "assistant" && m.fitScore);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Chat panel */}
      <div
        className="lg:col-span-2"
        style={{
          backgroundColor: CARD_BG,
          border: `1px solid ${BORDER}`,
          borderRadius: 14,
          overflow: "hidden",
          display: "flex",
          flexDirection: "column",
        }}
      >
        {/* Header */}
        <div
          style={{
            backgroundColor: NAVY,
            padding: "16px 20px",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <div className="flex items-center gap-3">
            <div
              style={{
                width: 36,
                height: 36,
                borderRadius: 8,
                backgroundColor: TEAL,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Bot size={18} color="white" />
            </div>
            <div>
              <div style={{ fontSize: 14, fontWeight: 600, color: "white" }}>Recruiter Concierge</div>
              <div style={{ fontSize: 11, color: "rgba(255,255,255,0.5)" }}>TransformIA AI Lab · Public-safe</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span style={{ width: 7, height: 7, borderRadius: "50%", backgroundColor: "#4ADE80", display: "inline-block" }} />
            <span style={{ fontSize: 11, color: "rgba(255,255,255,0.6)" }}>Active</span>
          </div>
        </div>

        {/* Disclaimer */}
        {showDisclaimer && (
          <div
            style={{
              backgroundColor: TEAL_LIGHT,
              borderBottom: `1px solid ${TEAL}22`,
              padding: "10px 16px",
              display: "flex",
              alignItems: "flex-start",
              gap: 8,
              fontSize: 12,
              color: TEAL,
            }}
          >
            <Shield size={13} style={{ flexShrink: 0, marginTop: 1 }} />
            <span>
              This concierge uses only public portfolio data. No calendar event is created without Daniel's explicit approval.
            </span>
            <button
              onClick={() => setShowDisclaimer(false)}
              style={{ background: "none", border: "none", cursor: "pointer", color: TEAL, marginLeft: "auto", padding: 0, fontSize: 16, lineHeight: 1 }}
            >
              ×
            </button>
          </div>
        )}

        {/* Messages */}
        <div
          style={{
            flex: 1,
            overflowY: "auto",
            padding: "20px 20px",
            display: "flex",
            flexDirection: "column",
            gap: 14,
            minHeight: 320,
            maxHeight: 420,
          }}
        >
          {messages.map((msg, i) => (
            <div key={i} className={`flex gap-3 ${msg.role === "user" ? "flex-row-reverse" : ""}`}>
              <div
                style={{
                  width: 32,
                  height: 32,
                  borderRadius: 8,
                  backgroundColor: msg.role === "user" ? NAVY : "#F0F0ED",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  flexShrink: 0,
                }}
              >
                {msg.role === "user" ? (
                  <User size={15} color="white" />
                ) : (
                  <Bot size={15} color={TEAL} />
                )}
              </div>
              <div style={{ maxWidth: "75%" }}>
                <div
                  style={{
                    backgroundColor: msg.role === "user" ? NAVY : "#F7F7F5",
                    color: msg.role === "user" ? "white" : NAVY,
                    borderRadius: msg.role === "user" ? "12px 4px 12px 12px" : "4px 12px 12px 12px",
                    padding: "11px 15px",
                    fontSize: 13,
                    lineHeight: 1.6,
                  }}
                >
                  {msg.content}
                </div>
                {msg.actions && (
                  <div className="flex flex-wrap gap-2 mt-2">
                    {msg.actions.map((action) => (
                      <button
                        key={action}
                        onClick={() => handleAction(action)}
                        style={{
                          backgroundColor: "transparent",
                          border: `1px solid ${TEAL}`,
                          borderRadius: 5,
                          padding: "5px 11px",
                          fontSize: 11,
                          color: TEAL,
                          fontWeight: 500,
                          cursor: "pointer",
                          display: "flex",
                          alignItems: "center",
                          gap: 5,
                        }}
                      >
                        {action.includes("interview") ? <Calendar size={11} /> : <Download size={11} />}
                        {action}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="flex gap-3">
              <div
                style={{
                  width: 32,
                  height: 32,
                  borderRadius: 8,
                  backgroundColor: "#F0F0ED",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  flexShrink: 0,
                }}
              >
                <Bot size={15} color={TEAL} />
              </div>
              <div
                style={{
                  backgroundColor: "#F7F7F5",
                  borderRadius: "4px 12px 12px 12px",
                  padding: "12px 16px",
                  display: "flex",
                  gap: 4,
                  alignItems: "center",
                }}
              >
                {[0, 1, 2].map((i) => (
                  <span
                    key={i}
                    style={{
                      width: 6,
                      height: 6,
                      borderRadius: "50%",
                      backgroundColor: "#B0B0B0",
                      display: "inline-block",
                      animation: `bounce 1.2s ease-in-out ${i * 0.2}s infinite`,
                    }}
                  />
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Suggested questions */}
        <div
          style={{
            borderTop: `1px solid ${BORDER}`,
            padding: "10px 16px",
            display: "flex",
            gap: 6,
            flexWrap: "wrap",
          }}
        >
          {SUGGESTED.slice(0, 3).map((q) => (
            <button
              key={q}
              onClick={() => send(q)}
              style={{
                backgroundColor: "#F4F4F1",
                border: `1px solid ${BORDER}`,
                borderRadius: 5,
                padding: "5px 10px",
                fontSize: 11,
                color: SECONDARY,
                cursor: "pointer",
                fontWeight: 400,
                textAlign: "left",
              }}
            >
              {q.length > 42 ? q.slice(0, 42) + "…" : q}
            </button>
          ))}
        </div>

        {/* Input */}
        <div
          style={{
            borderTop: `1px solid ${BORDER}`,
            padding: "14px 16px",
            display: "flex",
            gap: 8,
          }}
        >
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && send()}
            placeholder="Ask about Daniel's profile, skills or availability…"
            style={{
              flex: 1,
              border: `1px solid ${BORDER}`,
              borderRadius: 7,
              padding: "10px 14px",
              fontSize: 13,
              outline: "none",
              backgroundColor: "#FAFAF8",
              color: NAVY,
            }}
          />
          <button
            onClick={() => send()}
            disabled={!input.trim()}
            style={{
              backgroundColor: input.trim() ? NAVY : "#E4E4DF",
              color: "white",
              border: "none",
              borderRadius: 7,
              width: 40,
              height: 40,
              cursor: input.trim() ? "pointer" : "default",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0,
            }}
          >
            <Send size={16} />
          </button>
        </div>
      </div>

      {/* Side panel */}
      <div className="flex flex-col gap-4">
        {/* Fit score */}
        <div
          style={{
            backgroundColor: CARD_BG,
            border: `1px solid ${BORDER}`,
            borderRadius: 14,
            padding: "24px 20px",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            gap: 16,
          }}
        >
          <div style={{ fontSize: 12, fontWeight: 600, color: SECONDARY, letterSpacing: "0.06em", textTransform: "uppercase" }}>
            Role Fit Analysis
          </div>
          <FitScoreMeter score={lastAssistantMessage?.fitScore ?? 0} />
          {lastAssistantMessage?.cvRecommended && (
            <div
              style={{
                backgroundColor: TEAL_LIGHT,
                border: `1px solid ${TEAL}22`,
                borderRadius: 6,
                padding: "10px 12px",
                width: "100%",
                textAlign: "center",
              }}
            >
              <div style={{ fontSize: 10, color: TEAL, fontWeight: 600, letterSpacing: "0.06em", textTransform: "uppercase", marginBottom: 3 }}>
                Recommended CV
              </div>
              <div style={{ fontSize: 12, color: TEAL, fontWeight: 500 }}>{lastAssistantMessage.cvRecommended}</div>
            </div>
          )}
          <a
            href="#"
            style={{
              width: "100%",
              backgroundColor: NAVY,
              color: "white",
              padding: "10px 16px",
              borderRadius: 6,
              fontSize: 13,
              fontWeight: 500,
              textDecoration: "none",
              textAlign: "center",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 6,
            }}
          >
            <Download size={13} />
            Download CV
          </a>
        </div>

        {/* Pending approval card */}
        <div
          style={{
            backgroundColor: pendingApproval ? "#FFF8E7" : "#F7F7F5",
            border: `1px solid ${pendingApproval ? "#E8C84A" : BORDER}`,
            borderRadius: 14,
            padding: "20px",
          }}
        >
          <div className="flex items-center gap-2 mb-3">
            {pendingApproval ? (
              <Clock size={15} color="#B8860B" />
            ) : (
              <Shield size={15} color={SECONDARY} />
            )}
            <span
              style={{
                fontSize: 12,
                fontWeight: 600,
                color: pendingApproval ? "#7A5C00" : SECONDARY,
                letterSpacing: "0.04em",
                textTransform: "uppercase",
              }}
            >
              {pendingApproval ? "Pending Approval" : "Governance"}
            </span>
          </div>
          {pendingApproval ? (
            <p style={{ fontSize: 12, color: "#7A5C00", lineHeight: 1.6, marginBottom: 12 }}>
              Interview request sent. No calendar event will be created until Daniel reviews and approves.
            </p>
          ) : (
            <p style={{ fontSize: 12, color: SECONDARY, lineHeight: 1.6 }}>
              All actions — interviews, calendar bookings — require Daniel's explicit human approval.
            </p>
          )}
          {pendingApproval && (
            <div className="flex items-center gap-2">
              <span style={{ width: 7, height: 7, borderRadius: "50%", backgroundColor: "#F0B030", display: "inline-block" }} />
              <span style={{ fontSize: 11, color: "#7A5C00", fontWeight: 500 }}>Awaiting Daniel's response</span>
            </div>
          )}
        </div>

        {/* Suggested */}
        <div
          style={{
            backgroundColor: CARD_BG,
            border: `1px solid ${BORDER}`,
            borderRadius: 14,
            padding: "16px",
          }}
        >
          <div style={{ fontSize: 11, fontWeight: 600, color: SECONDARY, letterSpacing: "0.06em", textTransform: "uppercase", marginBottom: 10 }}>
            Suggested
          </div>
          <div className="flex flex-col gap-2">
            {SUGGESTED.slice(3).map((q) => (
              <button
                key={q}
                onClick={() => send(q)}
                style={{
                  background: "none",
                  border: `1px solid ${BORDER}`,
                  borderRadius: 6,
                  padding: "8px 12px",
                  textAlign: "left",
                  fontSize: 12,
                  color: SECONDARY,
                  cursor: "pointer",
                  lineHeight: 1.4,
                }}
              >
                {q}
              </button>
            ))}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes bounce {
          0%, 60%, 100% { transform: translateY(0); }
          30% { transform: translateY(-5px); }
        }
      `}</style>
    </div>
  );
}

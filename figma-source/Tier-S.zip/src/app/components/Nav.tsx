import { useState } from "react";
import { Link, useLocation } from "react-router";
import { Download, Menu, X } from "lucide-react";

const NAV = "#0B1D3A";

export function Nav() {
  const [open, setOpen] = useState(false);
  const location = useLocation();

  const links = [
    { href: "/#work", label: "Work" },
    { href: "/#credentials", label: "Credentials" },
    { href: "/#lab", label: "AI Lab" },
    { href: "/#concierge", label: "Concierge" },
    { href: "/#contact", label: "Contact" },
    { href: "/assets", label: "Assets" },
  ];

  const handleHash = (href: string) => {
    if (href.startsWith("/#")) {
      if (location.pathname !== "/") {
        window.location.href = href;
        return;
      }
      const id = href.replace("/#", "");
      const el = document.getElementById(id);
      if (el) {
        el.scrollIntoView({ behavior: "smooth" });
      }
    }
    setOpen(false);
  };

  return (
    <nav
      className="sticky top-0 z-50"
      style={{
        backgroundColor: "rgba(250,250,248,0.96)",
        borderBottom: "1px solid #E4E4DF",
        backdropFilter: "blur(8px)",
      }}
    >
      <div className="max-w-6xl mx-auto px-6 flex items-center justify-between" style={{ height: 64 }}>
        {/* Logo */}
        <Link to="/" className="flex items-center gap-3" style={{ textDecoration: "none" }}>
          <div
            style={{
              backgroundColor: NAV,
              color: "white",
              width: 36,
              height: 36,
              borderRadius: 4,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: 12,
              fontWeight: 700,
              letterSpacing: "0.08em",
              flexShrink: 0,
            }}
          >
            DMS
          </div>
          <div>
            <div style={{ color: "#1C1C1E", fontSize: 14, fontWeight: 600, lineHeight: 1.2 }}>
              Daniel Medina
            </div>
            <div style={{ color: "#8A8A8A", fontSize: 11, fontWeight: 400, letterSpacing: "0.02em" }}>
              AI Transformation Leader
            </div>
          </div>
        </Link>

        {/* Desktop links */}
        <div className="hidden md:flex items-center gap-7">
          {links.map((link) =>
            link.href.startsWith("/#") ? (
              <button
                key={link.href}
                onClick={() => handleHash(link.href)}
                style={{
                  background: "none",
                  border: "none",
                  padding: 0,
                  cursor: "pointer",
                  color: "#5A5A5A",
                  fontSize: 13,
                  fontWeight: 400,
                  letterSpacing: "0.01em",
                }}
              >
                {link.label}
              </button>
            ) : (
              <Link
                key={link.href}
                to={link.href}
                style={{
                  color: "#5A5A5A",
                  fontSize: 13,
                  fontWeight: 400,
                  textDecoration: "none",
                  letterSpacing: "0.01em",
                }}
              >
                {link.label}
              </Link>
            )
          )}
        </div>

        {/* CTA */}
        <div className="hidden md:flex items-center gap-3">
          <a
            href="mailto:Danielmedinasanchez86@gmail.com"
            style={{
              color: NAV,
              fontSize: 13,
              fontWeight: 500,
              textDecoration: "none",
              padding: "7px 14px",
              border: `1px solid ${NAV}`,
              borderRadius: 5,
            }}
          >
            Book Interview
          </a>
          <a
            href="#"
            style={{
              backgroundColor: NAV,
              color: "white",
              padding: "8px 16px",
              borderRadius: 5,
              fontSize: 13,
              fontWeight: 500,
              textDecoration: "none",
              display: "flex",
              alignItems: "center",
              gap: 6,
            }}
          >
            <Download size={13} />
            CV
          </a>
        </div>

        {/* Mobile toggle */}
        <button
          className="md:hidden"
          onClick={() => setOpen(!open)}
          style={{ background: "none", border: "none", cursor: "pointer", color: "#1C1C1E", padding: 4 }}
        >
          {open ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <div
          style={{
            borderTop: "1px solid #E4E4DF",
            backgroundColor: "#FAFAF8",
            padding: "16px 24px 20px",
          }}
        >
          {links.map((link) => (
            <div
              key={link.href}
              style={{ borderBottom: "1px solid #F0F0ED" }}
            >
              {link.href.startsWith("/#") ? (
                <button
                  onClick={() => handleHash(link.href)}
                  style={{
                    display: "block",
                    width: "100%",
                    textAlign: "left",
                    background: "none",
                    border: "none",
                    cursor: "pointer",
                    color: "#4A4A4A",
                    fontSize: 15,
                    padding: "12px 0",
                  }}
                >
                  {link.label}
                </button>
              ) : (
                <Link
                  to={link.href}
                  onClick={() => setOpen(false)}
                  style={{
                    display: "block",
                    color: "#4A4A4A",
                    fontSize: 15,
                    padding: "12px 0",
                    textDecoration: "none",
                  }}
                >
                  {link.label}
                </Link>
              )}
            </div>
          ))}
          <div className="flex gap-3 mt-4">
            <a
              href="mailto:Danielmedinasanchez86@gmail.com"
              style={{
                flex: 1,
                textAlign: "center",
                color: NAV,
                fontSize: 14,
                fontWeight: 500,
                textDecoration: "none",
                padding: "10px 14px",
                border: `1px solid ${NAV}`,
                borderRadius: 5,
              }}
            >
              Book Interview
            </a>
            <a
              href="#"
              style={{
                flex: 1,
                textAlign: "center",
                backgroundColor: NAV,
                color: "white",
                padding: "10px 14px",
                borderRadius: 5,
                fontSize: 14,
                fontWeight: 500,
                textDecoration: "none",
              }}
            >
              Download CV
            </a>
          </div>
        </div>
      )}
    </nav>
  );
}

import { Link } from "react-router";
import { ArrowLeft, Download, Linkedin, Image, Layout } from "lucide-react";

const NAVY = "#0B1D3A";
const TEAL = "#1A7A6E";
const TEAL_LIGHT = "#E8F5F2";
const SECONDARY = "#5A5A5A";
const BORDER = "#E4E4DF";
const CARD_BG = "#FFFFFF";
const PAGE_BG = "#FAFAF8";

function SectionTitle({ label, title }: { label: string; title: string }) {
  return (
    <div className="mb-8">
      <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.14em", color: TEAL, textTransform: "uppercase", marginBottom: 8 }}>
        {label}
      </div>
      <h2 style={{ fontSize: 26, fontWeight: 700, color: NAVY, letterSpacing: "-0.02em" }}>{title}</h2>
    </div>
  );
}

function AssetTag({ label }: { label: string }) {
  return (
    <span
      style={{
        backgroundColor: "#F0F0ED",
        borderRadius: 4,
        padding: "3px 9px",
        fontSize: 11,
        color: SECONDARY,
        fontWeight: 400,
      }}
    >
      {label}
    </span>
  );
}

/* ── LinkedIn Banner: Executive Light ── */
function BannerLight() {
  return (
    <div style={{ position: "relative", width: "100%", paddingTop: "25%", overflow: "hidden", borderRadius: 10, border: `1px solid ${BORDER}` }}>
      <div
        style={{
          position: "absolute",
          inset: 0,
          backgroundColor: "#FAFAF8",
          overflow: "hidden",
        }}
      >
        {/* Grid pattern */}
        <svg style={{ position: "absolute", inset: 0, width: "100%", height: "100%", opacity: 0.06 }}>
          <defs>
            <pattern id="bl-grid" width="32" height="32" patternUnits="userSpaceOnUse">
              <path d="M 32 0 L 0 0 0 32" fill="none" stroke={NAVY} strokeWidth="0.8" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#bl-grid)" />
        </svg>

        {/* Left accent bar */}
        <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: 4, backgroundColor: TEAL }} />

        {/* Content */}
        <div
          style={{
            position: "absolute",
            inset: 0,
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            paddingLeft: "6%",
          }}
        >
          <div style={{ fontSize: "clamp(14px,3vw,22px)", fontWeight: 800, color: NAVY, letterSpacing: "-0.02em", lineHeight: 1.1 }}>
            Daniel Medina Sánchez
          </div>
          <div style={{ fontSize: "clamp(9px,1.8vw,14px)", fontWeight: 600, color: TEAL, marginTop: "2%", letterSpacing: "0.01em" }}>
            AI Transformation & Digital Operations Leader
          </div>
          <div style={{ fontSize: "clamp(7px,1.3vw,11px)", color: SECONDARY, marginTop: "1.5%", letterSpacing: "0.03em" }}>
            Digital Workplace · ITSM · Public Sector · Human-in-the-Loop
          </div>
          <div
            style={{
              marginTop: "3%",
              display: "flex",
              gap: "2%",
              alignItems: "center",
              fontSize: "clamp(6px,1.1vw,10px)",
              color: "#888",
            }}
          >
            {["560+ people led", "€12M+ P&L", "CS50x + CS50AI", "Madrid / Remote"].map((m) => (
              <span key={m}>{m}</span>
            ))}
          </div>
        </div>

        {/* Right: subtle node cluster */}
        <svg style={{ position: "absolute", right: "5%", top: "10%", bottom: "10%", width: "25%", opacity: 0.12 }}>
          {[
            [50, 50], [80, 20], [80, 80], [20, 20], [20, 80],
            [50, 20], [50, 80], [30, 50], [70, 50],
          ].map(([cx, cy], i) => (
            <circle key={i} cx={`${cx}%`} cy={`${cy}%`} r="3" fill={NAVY} />
          ))}
          {[[50, 50, 80, 20], [50, 50, 80, 80], [50, 50, 20, 20], [50, 50, 20, 80],
            [50, 50, 30, 50], [50, 50, 70, 50], [50, 50, 50, 20], [50, 50, 50, 80]].map(([x1, y1, x2, y2], i) => (
            <line key={i} x1={`${x1}%`} y1={`${y1}%`} x2={`${x2}%`} y2={`${y2}%`} stroke={NAVY} strokeWidth="0.8" />
          ))}
        </svg>
      </div>
    </div>
  );
}

/* ── LinkedIn Banner: Navy Premium ── */
function BannerNavy() {
  return (
    <div style={{ position: "relative", width: "100%", paddingTop: "25%", overflow: "hidden", borderRadius: 10, border: `1px solid ${BORDER}` }}>
      <div
        style={{
          position: "absolute",
          inset: 0,
          background: `linear-gradient(135deg, #0B1D3A 0%, #1E3A5F 60%, #1A5A50 100%)`,
        }}
      >
        {/* Dot grid */}
        <svg style={{ position: "absolute", inset: 0, width: "100%", height: "100%", opacity: 0.08 }}>
          <defs>
            <pattern id="bn-dots" width="24" height="24" patternUnits="userSpaceOnUse">
              <circle cx="12" cy="12" r="1.2" fill="white" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#bn-dots)" />
        </svg>

        {/* Safe zone lower-left (for LinkedIn profile photo overlap) */}
        <div
          style={{
            position: "absolute",
            bottom: "8%",
            left: "2%",
            width: "22%",
            height: "60%",
            border: "1px dashed rgba(255,255,255,0.15)",
            borderRadius: 4,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <span style={{ fontSize: "clamp(5px,1vw,8px)", color: "rgba(255,255,255,0.25)", textAlign: "center", padding: "0 4px" }}>
            Profile photo safe zone
          </span>
        </div>

        {/* Content */}
        <div
          style={{
            position: "absolute",
            inset: 0,
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            paddingLeft: "27%",
          }}
        >
          <div style={{ fontSize: "clamp(14px,3vw,22px)", fontWeight: 800, color: "white", letterSpacing: "-0.02em", lineHeight: 1.1 }}>
            Daniel Medina Sánchez
          </div>
          <div style={{ fontSize: "clamp(9px,1.8vw,14px)", fontWeight: 500, color: "rgba(255,255,255,0.8)", marginTop: "2%" }}>
            AI Transformation & Digital Operations Leader
          </div>
          <div style={{ fontSize: "clamp(7px,1.3vw,11px)", color: "rgba(255,255,255,0.55)", marginTop: "1.5%", letterSpacing: "0.04em" }}>
            Digital Workplace · ITSM · Public Sector · Human-in-the-Loop
          </div>
          <div style={{ marginTop: "2.5%", display: "flex", gap: "2%", fontSize: "clamp(6px,1.1vw,10px)", color: "rgba(255,255,255,0.45)" }}>
            {["560+ people led", "€12M+ P&L", "CS50x + CS50AI", "Madrid / Remote"].map((m) => (
              <span key={m}>{m}</span>
            ))}
          </div>
        </div>

        {/* Right teal accent */}
        <div style={{ position: "absolute", right: 0, top: 0, bottom: 0, width: 4, backgroundColor: TEAL }} />
      </div>
    </div>
  );
}

function FeaturedCard({ title, subtitle, detail, badge, color }: {
  title: string; subtitle: string; detail: string; badge: string; color: string;
}) {
  return (
    <div
      style={{
        backgroundColor: CARD_BG,
        border: `1px solid ${BORDER}`,
        borderRadius: 10,
        overflow: "hidden",
      }}
    >
      {/* Card image area */}
      <div
        style={{
          backgroundColor: color,
          padding: "24px 22px 20px",
          position: "relative",
          overflow: "hidden",
          aspectRatio: "1200/627",
          display: "flex",
          flexDirection: "column",
          justifyContent: "flex-end",
        }}
      >
        <div style={{ position: "absolute", inset: 0, opacity: 0.07 }}>
          <svg width="100%" height="100%">
            <defs>
              <pattern id={`fc-${badge}`} width="30" height="30" patternUnits="userSpaceOnUse">
                <path d="M 30 0 L 0 0 0 30" fill="none" stroke="white" strokeWidth="0.6" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill={`url(#fc-${badge})`} />
          </svg>
        </div>
        <div
          style={{
            display: "inline-block",
            backgroundColor: "rgba(255,255,255,0.15)",
            borderRadius: 4,
            padding: "2px 9px",
            fontSize: 10,
            color: "rgba(255,255,255,0.8)",
            marginBottom: 8,
            fontWeight: 600,
            letterSpacing: "0.08em",
            textTransform: "uppercase",
            width: "fit-content",
          }}
        >
          {badge}
        </div>
        <div style={{ fontSize: "clamp(14px,2.5vw,18px)", fontWeight: 800, color: "white", lineHeight: 1.2, marginBottom: 6 }}>
          {title}
        </div>
        <div style={{ fontSize: "clamp(10px,1.6vw,13px)", color: "rgba(255,255,255,0.7)" }}>{subtitle}</div>
        <div style={{ fontSize: "clamp(9px,1.4vw,11px)", color: "rgba(255,255,255,0.5)", marginTop: 4 }}>{detail}</div>
      </div>
      {/* Card label */}
      <div style={{ padding: "12px 14px", borderTop: `1px solid ${BORDER}` }}>
        <span style={{ fontSize: 12, color: SECONDARY }}>{title}</span>
      </div>
    </div>
  );
}

const FEATURED_CARDS = [
  {
    title: "Daniel Medina Sánchez",
    subtitle: "AI Transformation & Digital Operations Leader",
    detail: "15+ years · 560+ people · €12M+ P&L · CS50x + CS50AI",
    badge: "CV Premium",
    color: NAVY,
  },
  {
    title: "CS50x + CS50AI",
    subtitle: "Computer Science for Artificial Intelligence",
    detail: "10 problem sets · final project · 12 AI Python projects",
    badge: "HarvardX",
    color: "#7A5C00",
  },
  {
    title: "Human-in-the-Loop AI Workflows",
    subtitle: "Public-safe architecture · Enterprise AI · AI enablement",
    detail: "n8n · Codex · GitHub · Figma · Python",
    badge: "TransformIA Lab",
    color: TEAL,
  },
  {
    title: "Ayesa · Konecta · TransformIA",
    subtitle: "Digital Workplace · Operations Transformation · AI Delivery",
    detail: "Public Sector · ITSM · 560+ people · €12M+ P&L",
    badge: "Case Studies",
    color: "#1E3A5F",
  },
];

const EXPORT_MAP = [
  "executive-one-pager-es.pdf",
  "executive-one-pager-en.pdf",
  "linkedin-banner-executive-light.png",
  "linkedin-banner-navy-premium.png",
  "linkedin-featured-cv.png",
  "linkedin-featured-harvard.png",
  "linkedin-featured-transformia.png",
  "linkedin-featured-case-studies.png",
  "portfolio-hero-desktop.png",
  "portfolio-hero-mobile.png",
  "portfolio-homepage.png",
  "case-study-template.png",
  "recruiter-concierge-mockup.png",
  "design-system-dev-handoff.png",
];

export function LinkedInAssetsPage() {
  return (
    <div style={{ backgroundColor: PAGE_BG, minHeight: "100vh" }}>
      {/* Header */}
      <div style={{ backgroundColor: NAVY, padding: "40px 0 32px" }}>
        <div className="max-w-5xl mx-auto px-6">
          <Link
            to="/"
            style={{ display: "inline-flex", alignItems: "center", gap: 6, color: "rgba(255,255,255,0.6)", textDecoration: "none", fontSize: 13, marginBottom: 20 }}
          >
            <ArrowLeft size={14} />
            Back to Portfolio
          </Link>
          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 10 }}>
            <Linkedin size={24} color="rgba(255,255,255,0.7)" />
            <h1 style={{ fontSize: 32, fontWeight: 800, color: "white", letterSpacing: "-0.02em" }}>LinkedIn Assets</h1>
          </div>
          <p style={{ fontSize: 15, color: "rgba(255,255,255,0.6)", maxWidth: 520 }}>
            Employment brand visual assets — banners, featured cards, one-pagers. Export-ready map included.
          </p>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-6 py-12">
        {/* Banners */}
        <SectionTitle label="03–04 · LinkedIn Banner" title="Banner Variants" />
        <div className="grid grid-cols-1 gap-8 mb-16">
          <div>
            <div style={{ fontSize: 12, fontWeight: 600, color: SECONDARY, letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 10 }}>
              03 · Executive Light
            </div>
            <BannerLight />
            <div className="flex gap-2 mt-3">
              {["1584 × 396 px", "Executive Light", "White / Warm"].map((t) => <AssetTag key={t} label={t} />)}
            </div>
          </div>
          <div>
            <div style={{ fontSize: 12, fontWeight: 600, color: SECONDARY, letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 10 }}>
              04 · Navy Premium
            </div>
            <BannerNavy />
            <div className="flex gap-2 mt-3">
              {["1584 × 396 px", "Navy Premium", "Dark / Executive"].map((t) => <AssetTag key={t} label={t} />)}
            </div>
          </div>
        </div>

        {/* Featured Cards */}
        <SectionTitle label="05 · LinkedIn Featured Cards" title="Featured Card Set" />
        <p style={{ fontSize: 14, color: SECONDARY, marginBottom: 24 }}>4 cards · 1200 × 627 px main format</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-16">
          {FEATURED_CARDS.map((card) => (
            <FeaturedCard key={card.badge} {...card} />
          ))}
        </div>

        {/* Executive One-Pager preview */}
        <SectionTitle label="01–02 · Executive One-Pager" title="One-Pager Preview (EN)" />
        <div
          style={{
            backgroundColor: CARD_BG,
            border: `1px solid ${BORDER}`,
            borderRadius: 12,
            padding: "40px 48px",
            maxWidth: 640,
            marginBottom: 40,
          }}
        >
          {/* Header */}
          <div style={{ borderBottom: `2px solid ${NAVY}`, paddingBottom: 20, marginBottom: 20 }}>
            <div style={{ fontSize: 28, fontWeight: 800, color: NAVY, letterSpacing: "-0.02em" }}>Daniel Medina Sánchez</div>
            <div style={{ fontSize: 15, fontWeight: 600, color: TEAL, marginTop: 4 }}>
              AI Transformation & Digital Operations Leader
            </div>
            <div style={{ fontSize: 12, color: SECONDARY, marginTop: 2 }}>
              Digital Workplace · ITSM · Public Sector · Human-in-the-Loop · CS50x + CS50AI
            </div>
            <div style={{ fontSize: 11, color: SECONDARY, marginTop: 8 }}>
              Danielmedinasanchez86@gmail.com · +34 646 285 942 · linkedin.com/in/danielmedina-ai
            </div>
          </div>

          {/* Value prop */}
          <p style={{ fontSize: 12, color: SECONDARY, lineHeight: 1.7, marginBottom: 16 }}>
            Hybrid business + technology + AI executive with 15+ years leading complex operations, teams of up to 560 people and €12M+ P&L. Technical foundation via HarvardX CS50x and CS50AI. Specialized in turning operational complexity into governed, measurable and AI-enabled work systems.
          </p>

          {/* Metrics bar */}
          <div
            style={{
              display: "flex",
              borderTop: `1px solid ${BORDER}`,
              borderBottom: `1px solid ${BORDER}`,
              padding: "12px 0",
              marginBottom: 16,
            }}
          >
            {[["15+", "YEARS"], ["560+", "PEOPLE LED"], ["3", "COUNTRIES"], ["+€12M", "P&L"], ["CS50x+AI", "HARVARDX"]].map(([v, l]) => (
              <div key={l} style={{ flex: 1, textAlign: "center", borderRight: `1px solid ${BORDER}` }} className="last:border-r-0">
                <div style={{ fontSize: 16, fontWeight: 800, color: NAVY }}>{v}</div>
                <div style={{ fontSize: 9, color: SECONDARY, letterSpacing: "0.06em" }}>{l}</div>
              </div>
            ))}
          </div>

          {/* Value areas */}
          <div className="grid grid-cols-3 gap-3 mb-16">
            {[
              { title: "AI Transformation", desc: "GenAI · HITL · Enablement · Automation" },
              { title: "Digital Workplace / ITSM", desc: "Modern Workplace · Atlassian JSM · Public Sector" },
              { title: "Operations Leadership", desc: "P&L · SLA/KPI · CX · Service Delivery" },
            ].map((a) => (
              <div key={a.title}>
                <div style={{ fontSize: 11, fontWeight: 700, color: NAVY, marginBottom: 4 }}>{a.title}</div>
                <div style={{ fontSize: 10, color: SECONDARY }}>{a.desc}</div>
              </div>
            ))}
          </div>

          {/* Experience blocks */}
          {[
            { org: "Ayesa", role: "Project Manager, Digital Workplace", highlight: "Public sector · ITSM · Madrid Digital · ICEX" },
            { org: "Konecta", role: "Business Manager · General Service Lead", highlight: "560 people · 3 countries · €12M+ P&L" },
            { org: "TransformIA AI Lab", role: "Founder · HITL Architect", highlight: "Proof-of-work · Human-in-the-Loop · public-safe" },
          ].map((e) => (
            <div key={e.org} style={{ marginBottom: 12, paddingBottom: 12, borderBottom: `1px solid ${BORDER}` }} className="last:border-b-0 last:mb-0 last:pb-0">
              <div style={{ fontSize: 12, fontWeight: 700, color: NAVY }}>{e.org}</div>
              <div style={{ fontSize: 11, color: SECONDARY }}>{e.role}</div>
              <div
                style={{
                  display: "inline-block",
                  backgroundColor: TEAL_LIGHT,
                  borderRadius: 3,
                  padding: "2px 7px",
                  fontSize: 10,
                  color: TEAL,
                  marginTop: 4,
                  fontWeight: 500,
                }}
              >
                {e.highlight}
              </div>
            </div>
          ))}

          {/* CTA */}
          <div
            style={{
              marginTop: 20,
              paddingTop: 16,
              borderTop: `1px solid ${BORDER}`,
              textAlign: "center",
              fontSize: 11,
              color: SECONDARY,
            }}
          >
            Available for remote · hybrid · Madrid-based roles
          </div>
        </div>

        {/* Export Map */}
        <SectionTitle label="17 · Export Map" title="Asset Export Map" />
        <div
          style={{
            backgroundColor: CARD_BG,
            border: `1px solid ${BORDER}`,
            borderRadius: 12,
            padding: "24px",
            marginBottom: 40,
          }}
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {EXPORT_MAP.map((file, i) => (
              <div
                key={file}
                className="flex items-center gap-3"
                style={{
                  padding: "8px 10px",
                  borderRadius: 6,
                  backgroundColor: i % 2 === 0 ? "#F7F7F5" : CARD_BG,
                }}
              >
                <Image size={13} color={TEAL} />
                <span style={{ fontSize: 12, color: SECONDARY, fontFamily: "monospace" }}>{file}</span>
              </div>
            ))}
          </div>
          <div
            style={{
              marginTop: 20,
              paddingTop: 16,
              borderTop: `1px solid ${BORDER}`,
              fontSize: 12,
              color: SECONDARY,
            }}
          >
            All assets designed to Next.js / Vercel deployment spec. CV PDFs → <code style={{ backgroundColor: "#F0F0ED", padding: "1px 5px", borderRadius: 3 }}>/public/cv</code>. No private code exposed.
          </div>
        </div>
      </div>
    </div>
  );
}

import { Link } from "react-router";
import { ArrowLeft, Code2, Layers, Type, Palette, Grid, Square, Monitor } from "lucide-react";

const NAVY = "#0B1D3A";
const TEAL = "#1A7A6E";
const TEAL_LIGHT = "#E8F5F2";
const SECONDARY = "#5A5A5A";
const BORDER = "#E4E4DF";
const CARD_BG = "#FFFFFF";
const PAGE_BG = "#FAFAF8";

function DSSection({ icon: Icon, title, children }: { icon: React.ElementType; title: string; children: React.ReactNode }) {
  return (
    <div style={{ marginBottom: 56 }}>
      <div className="flex items-center gap-3 mb-6" style={{ borderBottom: `1px solid ${BORDER}`, paddingBottom: 16 }}>
        <Icon size={18} color={TEAL} />
        <h2 style={{ fontSize: 18, fontWeight: 700, color: NAVY, letterSpacing: "-0.01em" }}>{title}</h2>
      </div>
      {children}
    </div>
  );
}

function Token({ name, value, preview }: { name: string; value: string; preview: React.ReactNode }) {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 14,
        padding: "10px 14px",
        backgroundColor: CARD_BG,
        border: `1px solid ${BORDER}`,
        borderRadius: 7,
      }}
    >
      <div style={{ width: 40, height: 40, flexShrink: 0 }}>{preview}</div>
      <div>
        <div style={{ fontSize: 12, fontWeight: 600, color: NAVY, fontFamily: "monospace" }}>{name}</div>
        <div style={{ fontSize: 11, color: SECONDARY, fontFamily: "monospace" }}>{value}</div>
      </div>
    </div>
  );
}

const COLORS = [
  { name: "--color-navy", value: "#0B1D3A", label: "Navy Primary" },
  { name: "--color-navy-mid", value: "#1E3A5F", label: "Navy Mid" },
  { name: "--color-teal", value: "#1A7A6E", label: "Teal Accent" },
  { name: "--color-teal-light", value: "#E8F5F2", label: "Teal Light" },
  { name: "--color-carbon", value: "#1C1C1E", label: "Carbon Text" },
  { name: "--color-secondary", value: "#5A5A5A", label: "Secondary Text" },
  { name: "--color-bg", value: "#FAFAF8", label: "Background" },
  { name: "--color-surface", value: "#F4F4F1", label: "Surface / Section" },
  { name: "--color-card", value: "#FFFFFF", label: "Card" },
  { name: "--color-border", value: "#E4E4DF", label: "Border" },
];

export function DesignSystemPage() {
  return (
    <div style={{ backgroundColor: PAGE_BG, minHeight: "100vh" }}>
      {/* Header */}
      <div style={{ backgroundColor: NAVY, padding: "40px 0 32px" }}>
        <div className="max-w-5xl mx-auto px-6">
          <Link
            to="/"
            style={{ display: "inline-flex", alignItems: "center", gap: 6, color: "rgba(255,255,255,0.6)", textDecoration: "none", fontSize: 13, marginBottom: 20 }}
          >
            <ArrowLeft size={14} />
            Back to Portfolio
          </Link>
          <div className="flex items-center gap-3 mb-10">
            <Code2 size={24} color="rgba(255,255,255,0.7)" />
            <h1 style={{ fontSize: 32, fontWeight: 800, color: "white", letterSpacing: "-0.02em" }}>Design System / Dev Handoff</h1>
          </div>
          <p style={{ fontSize: 14, color: "rgba(255,255,255,0.6)", maxWidth: 560 }}>
            Visual language and component spec for building danielmedina.ai in Next.js + TypeScript + Tailwind + Vercel.
          </p>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-6 py-12">
        {/* Stack */}
        <div
          style={{
            backgroundColor: CARD_BG,
            border: `1px solid ${BORDER}`,
            borderRadius: 12,
            padding: "24px 28px",
            marginBottom: 48,
            display: "flex",
            flexWrap: "wrap",
            gap: 12,
          }}
        >
          <div style={{ fontSize: 12, fontWeight: 600, color: SECONDARY, width: "100%", marginBottom: 4, letterSpacing: "0.08em", textTransform: "uppercase" }}>
            Recommended Stack
          </div>
          {[
            { label: "Framework", value: "Next.js 14+ / App Router" },
            { label: "Language", value: "TypeScript" },
            { label: "Styling", value: "Tailwind CSS v4" },
            { label: "Content", value: "MDX (case studies)" },
            { label: "Deploy", value: "Vercel" },
            { label: "CV PDFs", value: "/public/cv/" },
            { label: "AI (Concierge)", value: "Claude API + HITL gates" },
            { label: "Fonts", value: "Inter (Google Fonts)" },
          ].map((s) => (
            <div
              key={s.label}
              style={{
                backgroundColor: "#F4F4F1",
                border: `1px solid ${BORDER}`,
                borderRadius: 6,
                padding: "8px 14px",
              }}
            >
              <div style={{ fontSize: 10, color: SECONDARY, fontWeight: 600, letterSpacing: "0.06em", textTransform: "uppercase" }}>{s.label}</div>
              <div style={{ fontSize: 13, color: NAVY, fontWeight: 500, fontFamily: "monospace" }}>{s.value}</div>
            </div>
          ))}
        </div>

        {/* Colors */}
        <DSSection icon={Palette} title="Color Tokens">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {COLORS.map((c) => (
              <Token
                key={c.name}
                name={c.name}
                value={`${c.value} · ${c.label}`}
                preview={
                  <div
                    style={{
                      width: 40,
                      height: 40,
                      borderRadius: 6,
                      backgroundColor: c.value,
                      border: c.value === "#FFFFFF" || c.value === "#FAFAF8" ? `1px solid ${BORDER}` : "none",
                    }}
                  />
                }
              />
            ))}
          </div>
          <div
            style={{
              marginTop: 20,
              backgroundColor: "#F4F4F1",
              borderRadius: 8,
              padding: "14px 16px",
              fontSize: 12,
              color: SECONDARY,
              fontFamily: "monospace",
            }}
          >
            {`// tailwind.config.js (v4 compatible)\n// Use CSS custom properties, e.g.:\n.text-navy { color: var(--color-navy); }\n.bg-teal { background-color: var(--color-teal); }`}
          </div>
        </DSSection>

        {/* Typography */}
        <DSSection icon={Type} title="Typography">
          <div className="flex flex-col gap-4 mb-6">
            {[
              { label: "Display", size: 48, weight: 800, tracking: "-0.025em", sample: "AI Transformation Leader" },
              { label: "H1", size: 36, weight: 700, tracking: "-0.02em", sample: "Daniel Medina Sánchez" },
              { label: "H2", size: 28, weight: 700, tracking: "-0.02em", sample: "Case Studies" },
              { label: "H3", size: 18, weight: 600, tracking: "-0.01em", sample: "Digital Workplace / ITSM" },
              { label: "Body Large", size: 16, weight: 400, tracking: "0", sample: "Hybrid business + technology + AI executive" },
              { label: "Body", size: 14, weight: 400, tracking: "0", sample: "15+ years leading complex operations" },
              { label: "Small / Label", size: 12, weight: 500, tracking: "0.01em", sample: "Available · Remote · Hybrid" },
              { label: "Eyebrow", size: 11, weight: 600, tracking: "0.14em", sample: "CORE VALUE AREAS" },
            ].map((t) => (
              <div
                key={t.label}
                style={{
                  backgroundColor: CARD_BG,
                  border: `1px solid ${BORDER}`,
                  borderRadius: 8,
                  padding: "14px 16px",
                  display: "flex",
                  alignItems: "baseline",
                  gap: 20,
                  flexWrap: "wrap",
                }}
              >
                <div style={{ width: 120, flexShrink: 0 }}>
                  <div style={{ fontSize: 11, color: SECONDARY, fontWeight: 600, letterSpacing: "0.06em", textTransform: "uppercase" }}>{t.label}</div>
                  <div style={{ fontSize: 10, color: "#B0B0B0", fontFamily: "monospace", marginTop: 2 }}>{t.size}px / {t.weight} / {t.tracking || "0"}</div>
                </div>
                <div
                  style={{
                    fontSize: t.size,
                    fontWeight: t.weight,
                    letterSpacing: t.tracking,
                    color: NAVY,
                    lineHeight: 1.2,
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    whiteSpace: "nowrap",
                    flex: 1,
                    minWidth: 0,
                  }}
                >
                  {t.sample}
                </div>
              </div>
            ))}
          </div>
        </DSSection>

        {/* Spacing */}
        <DSSection icon={Grid} title="Spacing Scale">
          <div className="flex flex-wrap gap-4">
            {[4, 8, 12, 16, 20, 24, 32, 40, 48, 64, 80].map((s) => (
              <div key={s} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
                <div style={{ width: s, height: s, backgroundColor: NAVY, borderRadius: 2, opacity: 0.7 }} />
                <span style={{ fontSize: 10, color: SECONDARY, fontFamily: "monospace" }}>{s}px</span>
              </div>
            ))}
          </div>
        </DSSection>

        {/* Buttons */}
        <DSSection icon={Square} title="Buttons">
          <div className="flex flex-wrap gap-4 mb-6">
            {[
              { label: "Primary", bg: NAVY, color: "white", border: "none" },
              { label: "Secondary", bg: "transparent", color: NAVY, border: `1.5px solid ${NAVY}` },
              { label: "Teal CTA", bg: TEAL, color: "white", border: "none" },
              { label: "Ghost Teal", bg: TEAL_LIGHT, color: TEAL, border: `1px solid ${TEAL}33` },
              { label: "Ghost", bg: "#F4F4F1", color: SECONDARY, border: `1px solid ${BORDER}` },
              { label: "Destructive", bg: "#D4183D", color: "white", border: "none" },
            ].map((b) => (
              <button
                key={b.label}
                style={{
                  backgroundColor: b.bg,
                  color: b.color,
                  border: b.border || "none",
                  borderRadius: 6,
                  padding: "10px 20px",
                  fontSize: 13,
                  fontWeight: 500,
                  cursor: "default",
                  letterSpacing: "0.01em",
                }}
              >
                {b.label}
              </button>
            ))}
          </div>
          <div style={{ fontSize: 12, color: SECONDARY, fontFamily: "monospace", backgroundColor: "#F4F4F1", padding: "12px 16px", borderRadius: 7 }}>
            {`border-radius: 6px | padding: 10px 20px | font-size: 13px | font-weight: 500`}
          </div>
        </DSSection>

        {/* Metric cards */}
        <DSSection icon={Layers} title="Component Patterns">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {/* Metric card */}
            <div>
              <div style={{ fontSize: 12, fontWeight: 600, color: SECONDARY, marginBottom: 10, letterSpacing: "0.06em", textTransform: "uppercase" }}>Metric Card</div>
              <div
                style={{
                  backgroundColor: CARD_BG,
                  border: `1px solid ${BORDER}`,
                  borderRadius: 10,
                  padding: "20px 22px",
                  display: "flex",
                  flexDirection: "column",
                  gap: 6,
                }}
              >
                <div style={{ width: 16, height: 16, backgroundColor: TEAL, borderRadius: 3 }} />
                <div style={{ fontSize: 28, fontWeight: 700, color: NAVY, letterSpacing: "-0.02em", lineHeight: 1 }}>560+</div>
                <div style={{ fontSize: 12, color: SECONDARY }}>People Led</div>
              </div>
            </div>

            {/* Case card */}
            <div>
              <div style={{ fontSize: 12, fontWeight: 600, color: SECONDARY, marginBottom: 10, letterSpacing: "0.06em", textTransform: "uppercase" }}>Case Card</div>
              <div
                style={{
                  backgroundColor: CARD_BG,
                  border: `1px solid ${BORDER}`,
                  borderRadius: 10,
                  overflow: "hidden",
                }}
              >
                <div style={{ backgroundColor: NAVY, padding: "14px 16px" }}>
                  <div style={{ fontSize: 14, fontWeight: 700, color: "white" }}>Ayesa</div>
                  <div style={{ fontSize: 11, color: "rgba(255,255,255,0.6)" }}>Aug 2025 – Dec 2025</div>
                </div>
                <div style={{ padding: "14px 16px" }}>
                  <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                    {["Digital Workplace", "ITSM", "Public Sector"].map((t) => (
                      <span key={t} style={{ backgroundColor: "#F0F0ED", borderRadius: 4, padding: "3px 8px", fontSize: 10, color: SECONDARY }}>
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Tag / Badge */}
            <div>
              <div style={{ fontSize: 12, fontWeight: 600, color: SECONDARY, marginBottom: 10, letterSpacing: "0.06em", textTransform: "uppercase" }}>Tags & Badges</div>
              <div className="flex flex-wrap gap-2">
                <span style={{ backgroundColor: TEAL_LIGHT, color: TEAL, borderRadius: 20, padding: "4px 12px", fontSize: 12, fontWeight: 500, border: `1px solid ${TEAL}33` }}>
                  ● Available · Remote
                </span>
                <span style={{ backgroundColor: "#F0F0ED", color: SECONDARY, borderRadius: 4, padding: "3px 9px", fontSize: 11 }}>
                  Human-in-the-Loop
                </span>
                <span style={{ backgroundColor: "#FFF8E7", color: "#7A5C00", borderRadius: 4, padding: "3px 9px", fontSize: 11, border: "1px solid #E8C84A" }}>
                  HarvardX
                </span>
              </div>
            </div>

            {/* CV Download button */}
            <div>
              <div style={{ fontSize: 12, fontWeight: 600, color: SECONDARY, marginBottom: 10, letterSpacing: "0.06em", textTransform: "uppercase" }}>CV Download</div>
              <div className="flex gap-3">
                <button
                  style={{
                    backgroundColor: NAVY,
                    color: "white",
                    border: "none",
                    borderRadius: 6,
                    padding: "10px 18px",
                    fontSize: 13,
                    fontWeight: 500,
                    cursor: "pointer",
                    display: "flex",
                    alignItems: "center",
                    gap: 7,
                  }}
                >
                  ↓ Download CV (EN)
                </button>
                <button
                  style={{
                    backgroundColor: "transparent",
                    color: NAVY,
                    border: `1px solid ${NAVY}`,
                    borderRadius: 6,
                    padding: "10px 18px",
                    fontSize: 13,
                    fontWeight: 500,
                    cursor: "pointer",
                  }}
                >
                  CV (ES)
                </button>
              </div>
            </div>
          </div>
        </DSSection>

        {/* Responsive notes */}
        <DSSection icon={Monitor} title="Responsive Notes">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
            {[
              { label: "Mobile", bp: "< 640px", notes: ["Single column layout", "Nav collapses to hamburger", "Hero stacks vertically", "Metric cards wrap", "Touch-friendly tap targets 44px+"] },
              { label: "Tablet", bp: "640px – 1024px", notes: ["2-column grid for case cards", "Side panel in concierge collapses", "Banner scales to viewport", "Typography scales with clamp()"] },
              { label: "Desktop", bp: "> 1024px", notes: ["2-column hero with float cards", "3-col value areas grid", "Full concierge 2+1 layout", "Max-width 1200px container"] },
            ].map((r) => (
              <div
                key={r.label}
                style={{
                  backgroundColor: CARD_BG,
                  border: `1px solid ${BORDER}`,
                  borderRadius: 10,
                  padding: "18px 18px",
                }}
              >
                <div style={{ fontSize: 14, fontWeight: 700, color: NAVY, marginBottom: 4 }}>{r.label}</div>
                <div style={{ fontSize: 11, color: TEAL, fontFamily: "monospace", marginBottom: 10 }}>{r.bp}</div>
                <ul style={{ margin: 0, padding: "0 0 0 14px" }}>
                  {r.notes.map((n) => (
                    <li key={n} style={{ fontSize: 12, color: SECONDARY, marginBottom: 4, lineHeight: 1.5 }}>{n}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </DSSection>

        {/* Public-safe rules */}
        <DSSection icon={Code2} title="Public-Safe Design Rules">
          <div
            style={{
              backgroundColor: CARD_BG,
              border: `1px solid ${BORDER}`,
              borderRadius: 10,
              padding: "20px 22px",
            }}
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                { rule: "No private code", detail: "All demos use public patterns only. No client code, no CS50 solutions." },
                { rule: "No real client data", detail: "Financial figures are general in nature. No specific client metrics exposed." },
                { rule: "No false ROI claims", detail: "All impact statements are factual and verifiable from professional record." },
                { rule: "HITL all actions", detail: "Recruiter Concierge: no calendar, contact or data action without explicit approval." },
                { rule: "Pending approval state", detail: "All sensitive workflow steps must show 'Pending [Name] approval' status." },
                { rule: "No compliance claims", detail: "Do not claim certified compliance unless formally audited and documented." },
              ].map((r) => (
                <div key={r.rule} style={{ borderBottom: `1px solid ${BORDER}`, paddingBottom: 12 }} className="last:border-b-0 last:pb-0">
                  <div style={{ fontSize: 13, fontWeight: 600, color: NAVY, marginBottom: 3 }}>{r.rule}</div>
                  <div style={{ fontSize: 12, color: SECONDARY }}>{r.detail}</div>
                </div>
              ))}
            </div>
          </div>
        </DSSection>

        {/* Dev notes */}
        <div
          style={{
            backgroundColor: NAVY,
            borderRadius: 12,
            padding: "28px",
            color: "white",
          }}
        >
          <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 16, color: "rgba(255,255,255,0.9)" }}>
            Developer Notes for Next.js Build
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              { key: "Framework", val: "Next.js 14+ App Router · TypeScript · Tailwind v4" },
              { key: "Deploy", val: "Vercel · automatic previews per branch" },
              { key: "Case Studies", val: "MDX files in /content/cases/ · frontmatter for metadata" },
              { key: "CV PDFs", val: "/public/cv/ · served as static assets" },
              { key: "Fonts", val: "next/font/google · Inter variable · preload" },
              { key: "Concierge (v1)", val: "Deterministic responses from public portfolio data only" },
              { key: "Concierge (v2)", val: "Claude API + RAG on public docs · HITL approval gates" },
              { key: "Analytics", val: "Vercel Analytics · no personal data collection" },
            ].map((n) => (
              <div key={n.key} className="flex gap-3">
                <span style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", fontFamily: "monospace", minWidth: 100, flexShrink: 0 }}>{n.key}:</span>
                <span style={{ fontSize: 11, color: "rgba(255,255,255,0.7)", fontFamily: "monospace" }}>{n.val}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

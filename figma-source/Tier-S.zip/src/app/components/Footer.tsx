import { Mail, Linkedin, Github, MapPin } from "lucide-react";

export function Footer() {
  return (
    <footer
      style={{
        backgroundColor: "#0B1D3A",
        color: "white",
        borderTop: "1px solid #1E3A5F",
      }}
    >
      <div className="max-w-6xl mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div
                style={{
                  backgroundColor: "rgba(255,255,255,0.12)",
                  border: "1px solid rgba(255,255,255,0.2)",
                  width: 38,
                  height: 38,
                  borderRadius: 4,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: 12,
                  fontWeight: 700,
                  letterSpacing: "0.08em",
                  color: "white",
                }}
              >
                DMS
              </div>
              <div>
                <div style={{ fontSize: 14, fontWeight: 600, color: "white" }}>Daniel Medina Sánchez</div>
                <div style={{ fontSize: 12, color: "rgba(255,255,255,0.55)", marginTop: 1 }}>
                  AI Transformation & Digital Operations Leader
                </div>
              </div>
            </div>
            <p style={{ fontSize: 13, color: "rgba(255,255,255,0.6)", lineHeight: 1.7, maxWidth: 280 }}>
              Hybrid business + technology + AI executive. Turning operational complexity into governed, measurable work systems.
            </p>
            <div className="flex items-center gap-1 mt-3">
              <MapPin size={12} color="rgba(255,255,255,0.45)" />
              <span style={{ fontSize: 12, color: "rgba(255,255,255,0.45)" }}>Madrid, Spain · Remote · Hybrid</span>
            </div>
          </div>

          {/* Links */}
          <div>
            <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.12em", color: "rgba(255,255,255,0.4)", marginBottom: 16, textTransform: "uppercase" }}>
              Navigate
            </div>
            {[
              { label: "Case Studies", href: "/#work" },
              { label: "AI Lab · TransformIA", href: "/#lab" },
              { label: "Credentials", href: "/#credentials" },
              { label: "Recruiter Concierge", href: "/#concierge" },
              { label: "LinkedIn Assets", href: "/assets" },
              { label: "Design System", href: "/design-system" },
            ].map((l) => (
              <a
                key={l.href}
                href={l.href}
                style={{
                  display: "block",
                  color: "rgba(255,255,255,0.6)",
                  fontSize: 13,
                  textDecoration: "none",
                  marginBottom: 8,
                  lineHeight: 1.5,
                }}
              >
                {l.label}
              </a>
            ))}
          </div>

          {/* Contact */}
          <div>
            <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.12em", color: "rgba(255,255,255,0.4)", marginBottom: 16, textTransform: "uppercase" }}>
              Contact
            </div>
            <div className="flex flex-col gap-3">
              <a
                href="mailto:Danielmedinasanchez86@gmail.com"
                className="flex items-center gap-3"
                style={{ color: "rgba(255,255,255,0.7)", fontSize: 13, textDecoration: "none" }}
              >
                <Mail size={14} color="rgba(255,255,255,0.45)" />
                Danielmedinasanchez86@gmail.com
              </a>
              <a
                href="https://linkedin.com/in/danielmedina-ai"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3"
                style={{ color: "rgba(255,255,255,0.7)", fontSize: 13, textDecoration: "none" }}
              >
                <Linkedin size={14} color="rgba(255,255,255,0.45)" />
                linkedin.com/in/danielmedina-ai
              </a>
              <div className="flex items-center gap-3">
                <Github size={14} color="rgba(255,255,255,0.45)" />
                <span style={{ color: "rgba(255,255,255,0.45)", fontSize: 13 }}>GitHub · public-safe soon</span>
              </div>
              <a
                href="tel:+34646285942"
                className="flex items-center gap-3"
                style={{ color: "rgba(255,255,255,0.7)", fontSize: 13, textDecoration: "none" }}
              >
                <span style={{ color: "rgba(255,255,255,0.45)", fontSize: 13 }}>📞</span>
                +34 646 285 942
              </a>
            </div>
            <a
              href="mailto:Danielmedinasanchez86@gmail.com"
              style={{
                display: "inline-flex",
                marginTop: 20,
                backgroundColor: "#1A7A6E",
                color: "white",
                padding: "10px 20px",
                borderRadius: 5,
                fontSize: 13,
                fontWeight: 500,
                textDecoration: "none",
                letterSpacing: "0.01em",
              }}
            >
              Book an Interview →
            </a>
          </div>
        </div>

        <div
          style={{
            borderTop: "1px solid rgba(255,255,255,0.08)",
            marginTop: 40,
            paddingTop: 20,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            flexWrap: "wrap",
            gap: 8,
          }}
        >
          <span style={{ fontSize: 12, color: "rgba(255,255,255,0.3)" }}>
            © 2026 Daniel Medina Sánchez · All rights reserved
          </span>
          <span style={{ fontSize: 12, color: "rgba(255,255,255,0.3)" }}>
            Available for remote · hybrid · Madrid-based roles
          </span>
        </div>
      </div>
    </footer>
  );
}
